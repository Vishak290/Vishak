==========
DISCLAIMER
==========

THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


================
IMPORTANT NOTICE 
================
 
This script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Remote Desktop Services.

The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses, PC names and user names.

The script will save the collected data in a subfolder and also compress the results into a ZIP file. The folder or ZIP file are not automatically sent to Microsoft. 

You can send the ZIP file to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have. 

Find our privacy statement here: https://privacy.microsoft.com/en-us/privacy 


======================
How to use RDS-Collect
======================

The script must be run with elevated permissions in order to collect all required data. It works on any Windows client and Windows server OS supporting at least PowerShell 5.1.

Run the script on any Windows based device where you want to collect data for RDS/RDP troubleshooting scenarios.

The script will automatically archive all collected data into a .zip file located in the same folder as the script itself.


Usage example
-------------

	.\RDS-Collect.ps1 


PowerShell ExecutionPolicy
--------------------------

If the script does not start, complaining about execution restrictions, then in an elevated PowerShell console run:

	Set-ExecutionPolicy -ExecutionPolicy Bypass -Force -Scope Process

and verify with "Get-ExecutionPolicy -List" that no ExecutionPolicy with higher precedence is blocking execution of this script.
After that run the RDS-Collect script again.

If you cannot change the ExecutionPolicy settings or a higher restriction applies that blocks execution of the script, please ask your domain admin (or the responsible team) for a temporary exemption.


Once the script has started, p​​​lease read the "IMPORTANT NOTICE" message and confirm if you agree to continue with the data collection.

Depending on the amount of data that needs to be collected, the script may need run for several minutes. Please wait until the script finishes collecting all the data.

If you are missing any of the data that the tool should normally collect, check the content of "*_RDS-Collect-Output.txt" and "*_RDS-Collect-Errors.txt" for more information. Some data may not be present during data collection and thus not picked up by the script. This should be visible in one of the two text files.


====================
Data being collected
====================

The collected data is stored in a subfolder under the same folder where the script is located and at the end of the data collection, the results are archived into a .zip file. No data is automatically uploaded to Microsoft.

The script collects the following set of "default data" regardless if command line parameters have been specified:

• Membership information for the following groups:
	o Offer Remote Assistance Helpers
	o RDS Management Servers
	o RDS Remote Access Servers
	o RDS Endpoint Servers
	o Remote Desktop Users​​
• Registry keys:
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Terminal Server Client  
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList 
	o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation
	o HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Cryptography
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL
	o HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server​​
• Event Logs:
	o Application
	o Microsoft-Windows-CAPI2 (Operational)
	o Microsoft-Windows-RemoteAssistance (Admin + Operational)​
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreCDV (Admin + Operational)
	o Microsoft-Windows-RemoteDesktopServices-RdpCoreTS (Admin + Operational)
	o Microsoft-Windows-SMBClient (Connectivity + Operational + Security)
	o Microsoft-Windows-SMBServer (Connectivity + Operational + Security)
	o Microsoft-Windows-TerminalServices-LocalSessionManager (Admin + Operational)
	o Microsoft-Windows-TerminalServices-PnPDevices (Admin + Operational)
	o Microsoft-Windows-TerminalServices-RemoteConnectionManager (Admin + Operational)
	o Microsoft-Windows-User Profile Service (Operational)
	o Microsoft-Windows-VHDMP (Operational)
	o Security
	o System
• Gpresult output in html format
• Details of the running processes and services
• Networking information (profiles, firewall rules, netstat -anob, ipconfig /all, proxy settings)
• SPN information
• Certificate and thumbprint information
• Get-Hotfix output
• File versions of the running and some key binaries
• Basic system information


==========
Tool Owner
==========
Robert Klemencz @ Microsoft Customer Service and Support

