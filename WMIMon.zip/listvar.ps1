ls variable:WMI*
get-process -ID $WMIMON_PID


