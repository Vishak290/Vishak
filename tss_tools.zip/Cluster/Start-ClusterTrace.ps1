﻿#Requires -version 3.0
#Requires -RunAsAdministrator

# the cluster tracer 3.0

<#
    Manually restart tracing by event (run on a cluster node in PowerShell):

    Write-EventLog -Source PowerShell -LogName "Windows PowerShell" -EntryType Information -Message "Stop tracing event sent by $(hostname)`." -EventId 57350

    Manually terminate tracing by event (run on a cluster node in PowerShell):

    Write-EventLog -Source PowerShell -LogName "Windows PowerShell" -EntryType Information -Message "Terminate tracing event sent by $(hostname)`." -EventId 5709


    TO-DO:

    - GitHub
    - Sign and publish
    - Dynamic password generation for credential hashing - store decrypt encoded command in win\temp with system owner/perms only
#>

<#
    LIMITED USE LICENSE

    This PowerShell script (the “software”) is provided AS-IS with no warranties or guarantees, explicit  
    or implied, and is to be used exclusively for troubleshooting in conjunction with an active and open 
    Microsoft support case (the “case”). By using the software the Microsoft support case customer (the 
    “customer”) agrees to abide by this agreement. The software is provided to assist with complex data 
    collection needed for specific supports cases. Use of the software without direction from Microsoft 
    support is strictly prohibited.

    While the software has been internally tested, Microsoft can make no guarantees that the software will 
    operate without issue in the customer environment. Microsoft cannot guarantee that by using the software 
    all the necessary information for the case will be gathered. The customer should test the software in a 
    similar QA or testing environment prior to any use in a production environment. Microsoft support will make 
    a best effort, deemed appropriate by Microsoft support, to assist with software use to collect case pertinent 
    data. If the software does not work as intended the Microsoft support agent may decide to use an alternate 
    method rather than supporting, updating or fixing the software.

    The software will NOT be serviced, updated, fixed, or in any way supported once the case for which the 
    software was provided has been closed. Any support requests for the software sent to Microsoft, including 
    all Microsoft support entities, after case closure, archival, contract expiration or any other disengagement 
    of troubleshooting will be denied.


    PRIVACY NOTICE

    This PowerShell script gathers network data and diagnostics information from a Windows system. This data 
    should only be sent to Microsoft through the secure upload workspace provided by the support engineer to 
    ensure it is securely sent to Microsoft. Microsoft policy requires that all customer data be stored on secured 
    and fully encrypted systems. Every precaution is taken to ensure your data remains safe.

    The data will only be used to troubleshoot the case issue. All case data sent to Microsoft will be deleted 
    within 90 days of case closure.

#>


<#
.SYNOPSIS
    Collects cluster data until one of three common failover events occurs. Data collection is then halted on all cluster nodes.
.DESCRIPTION
    Collects cluster data until one of three common failover events occurs. Data collection is then halted on all cluster nodes. All parameters are optional. The parameter defaults are the recommended values. Please do not change any parameters without test and research.
.PARAMETER traceNic
    A text menu for NIC selection. One NIC can be selected at a time. Press Enter when the selection has been made.
    
    This reduces the packet duplication in the network trace (part of the ETL file). The menu will not appear if there is only a single NIC.

    Select [A]ll to trace on all interfaces. Use [D]one when all NICs have been selected.
.EXAMPLE
    Start-ClusterTrace
    
    Collects only network tracing as part of circular logging. Basic post-tracing data is always collected. Data is saved to C:\Traces.
.EXAMPLE
    Start-ClusterTrace -GetClusLogs -GetNetFT
    
    Collects network and NetFT tracing as part of circular logging. Gather cluster logs after a failover event triggers a stop. Data is saved to C:\Traces.
.EXAMPLE
    Start-ClusterTrace -GetClusLogs -GetNetFT -asTask
    
    Restarts data collection as a SYSTEM task. Collects network and NetFT tracing as part of circular logging. Gather cluster logs after a failover event triggers a stop. Data is saved to C:\Traces.

.EXAMPLE
    Start-ClusterTrace -tracePath E:\Temp -GetClusLogs -GetNetFT -GetPerfmon -udpOnly -asTask -taskRestart
    
    Restarts data collection as a SYSTEM task. Failovers restart data collection under a new child directory in E:\Temp. Collects network, performance, and NetFT tracing as part of circular logging. Gather cluster logs after a failover event triggers a stop. 
    
    Data collection needs to be stopped by running the Stop-ClusterTrace_MSFT-Nets task in Task Scheduler or "Start-ScheduledTask Stop-ClusterTrace_MSFT-Nets" in PowerShell.
.NOTES
    Author: Microsoft CSS
    Please file issues on GitHub @ https://github.com/microsoft/Start-ClusterTrace
.LINK
    More projects               : https://github.com/topics/msftnet
    Windows Networking Blog     : https://blogs.technet.microsoft.com/networking/
#>

[CmdletBinding()]
param (
        <#
        Root path to where data is collected. A child direcotry is created with a timestamp at this location. The complete data archive (ZIP or CAB) can be found at this location.
        
        Default: C:\Traces
        #>
        [parameter(Position=0)]
        [Alias("Path")]
        [string]$tracePath = "C:\Traces",

        <#
        A list of all the nodes in the cluster. This parameter is auto-generated based on Get-Cluster. Use a string array ([string[]]) when a subset of cluster nodes need to be traced.
        
        Default: Auto-generated based on Get-Cluster. Will prompt if Get-Cluster cannot find the cluster node names.
        #>
        [parameter(Position=1)]
        [Alias("Nodes")]
        [String[]]$remoteComputer = $(
                                        [string[]]$tmpClusNames = Get-Cluster $tmpClusNames -EA SilentlyContinue | ForEach-Object { $_.Name } 

                                        if (-NOT $tmpClusNames)
                                        {
                                            $tmpCount = 0
                                            
                                            do
                                            {
                                                $tmpClusName = Read-Host "Cluster not detected. Please enter the cluster name"
                                                if ($tmpClusName -ne "" -and $null -ne $tmpClusName)
                                                {
                                                    try 
                                                    {
                                                        $tmpClusNames = Get-Cluster $tmpClusNames -EA Stop | ForEach-Object { $_.Name }
                                                    }
                                                    catch 
                                                    {
                                                        Write-Warning "Failed to resolve nodes for $tmpClusName. Error: $($error[0].ToString())"
                                                    }
                                                }

                                                $tmpCount++
                                            } until ($tmpClusNames -or $tmpCount -ge 3)
                                        }

                                        if ($tmpClusNames)
                                        {
                                            $tmpClusNames
                                        } else {
                                            $null
                                        }
                                    ),
        
        ## the next three parameters are a set of three correlated arrays.
        ## each position in each array corresponds to a single event.

        <#
        The first of three correlated string arrays used to create stop events. The default log names (Event Viewer) are three most common cluster failover events.
        
        Default: "SYSTEM","SYSTEM","SYSTEM"
        #>
        [parameter(Position=2)]
        [String[]]$logName = ("SYSTEM","SYSTEM","SYSTEM"),
        
        <#
        The second of three correlated string arrays used to create stop events. The default Event ID's are three most common cluster failover events.
        
        Default: 1135,1006,1177
        #>
        [parameter(Position=3)]
        [int[]]$eventID = (1135,1006,1177),
        
        <#
        The third of three correlated string arrays used to create stop events. The default event provider names of the three most common cluster failover events. The provider names are needed because the event ID's are not unique.
        
        Default: "Microsoft-Windows-FailoverClustering","Microsoft-Windows-FailoverClustering","Microsoft-Windows-FailoverClustering"
        #>
        [parameter(Position=4)]
        [string[]]$provider = ("Microsoft-Windows-FailoverClustering","Microsoft-Windows-FailoverClustering","Microsoft-Windows-FailoverClustering"),


        <# 
        Size in MB of the ETL trace file. This is a circular log, and will not exceed this size. Do not use a value larger than 2048!

        Default: 1024
        #>
        [parameter(Position=5)]
        [Alias("maxSize")]
        [int]$fileSize = 1024,
        

        # see help comments above
        [Alias("NIC")]
        [string[]]$traceNic = $(        
                        $isNetAdapter = Get-Command Get-NetAdapter -EA SilentlyContinue
                        if ($isNetAdapter) 
                        {
                            [array]$NICs = (Get-NetAdapter | Where-Object {$_.Status -eq "Up" -and ($_.InterfaceType -eq 6 -or $_.InterfaceType -eq 71)}).Name
                        } else
                        {  
                            [array]$nicIdx = Get-WmiObject Win32_NetworkAdapterConfiguration | ForEach-Object {$_.Index}
                            [array]$NICs = Get-WmiObject Win32_NetworkAdapter | Where-Object {$nicIdx -contains $_.DeviceID -and $_.NetConnectionStatus -eq 2} | ForEach-Object {$_.NetConnectionID}
                        }
                    
                        if ($nics.count -eq 1) {
                            $nics[0]
                        } elseif ($nics.count -gt 1) {
                            $opts = @()

                            $count = 1
                            foreach ($nic in $nics) {
                        
                                $tmp = [PSCustomObject]@{
                                    Idx = $count
                                    Name = $nic
                                    Selected = $false
                                }

                                $opts += $tmp

                                $count++
                            }

                            do {
                                Clear-Host
                                Write-Host "NIC Selection"
                                Write-Host "Select network adapter(s) for packet capture:"

                                $opts | Foreach-Object { 
                                    if ($_.Selected -eq $false)
                                    {
                                        Write-Host "[$($_.Idx)] - $($_.Name)"
                                    }
                                    else 
                                    {
                                        Write-Host "[*] - $($_.Name)"
                                    }
                                }

                                Write-Host "[A] - All"
                                Write-Host "[D] - Done"
                                Write-Host "[?] - Help"
                                
                                $selection = Read-Host "`nSelection"


                                switch -Regex ($selection) {
                                    "d"
                                    {
                                        if (!$selection) {
                                            Write-Host "No network adapter was selected. Aborting script."
                                            exit
                                        }
                                        break
                                    }
                                    
                                    "a"
                                    {
                                        $selection = $null
                                        break
                                    }
                                    
                                    "\d"
                                    {
                                        if ($opts[($selection - 1)])
                                        {
                                            $opts[($selection - 1)].Selected = $true
                                        }
                                        break
                                    }

                                    "\?"
                                    {
                                        Clear-Host
                                        Write-Host "How to use the network adapter selection menu
    - Enter the number corresponding to the NIC you wish to capture packets. 
    - Press Enter. 
    - Repeat until all NICs are selected.
    - Enter D (upper or lower case) when done.
    - Enter A (upper or lower case) to select all NICs.
    - Adapters with [*] are ones that have already been selected.
    
Press any key to continue..."
                                        $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
                                        break
                                    }

                                    default 
                                    {
                                        break
                                    }
                                }
                            } until ($selection -eq "a" -or $selection -eq "d" -or !($opts | Where-Object { $_.Selected -eq $false}))

                            $opts | Where-Object { $_.Selected } | ForEach-Object { $_.Name }
                        } else {
                            $null
                        }
        ),

        <# 
        Truncates the bytes per packets recorded in the trace. Same as snaplen in tcpdump and Wireshark.

        Default: 1500
        #>
        [Alias("snapLen")]
        [int]$truncLenB = 1500,
        
        # Enables NetFT tracing. This creates a circular up to 1GB. 
        [Alias("traceNetFT")]
        [switch]$GetNetFT = $false,
        # Enables cluster log collection during post-tracing data collection. Cluster logs will consume ~150MB per node.
        [Alias("getClusterLogs")]
        [switch]$GetClusLogs = $false,
        # Enables performance monitor (perfmon) logging. This creates a circular log up to 300MB.
        [Alias("PerfmonLogs")]
        [switch]$GetPerfmon = $false,

        # Caputre only UDP packets. This is useful on extremely busy clusters where only cluster heartbeat traffic is needed.
        [switch]$udpOnly = $false,

        <# 
        Restarts the script as a SYSTEM task. You will be prompted for domain credentials, which will be hashed, encrypted, and stored in a location that requires Administrator rights.

        This makes the script execution user independent (the user executing the script can logoff) and reboot resilient, as the task executes on startup. 

        The Domain account needed must have Administrator rights to all cluster nodes. No account details are stored in plain text, but the process is reversible.

        If security is a concern, which it should always be, it is recommended that a special Service Account be used with access to only the cluster nodes. The account only needs rights to remote into other nodes and add an event viewer event.

        Run the Stop-ClusterTrace_MSFT-Nets task to end tracing. Please to not try to stop the Stop-ClusterTrace_MSFT-Nets.
        #>
        [switch]$asTask = $false,
        <# 
        Restarts the system task after a stop event which immediately restarts tracing in a new data collection folder. This replaces the default behavior of stopping and cleaning up. -asTask is implied (will set asTask to true when not set).

        Run the Stop-ClusterTrace_MSFT-Nets task to end tracing. Please to not try to stop the Stop-ClusterTrace_MSFT-Nets.
        #>
        [switch]$taskRestart = $false,

        # Do no use. Used to clean up tasks created with -asTask.
        [switch]$clean = $false,

        # Skips the validation phase of the script.
        [switch]$skipValidation = $false
    )

#### Variables and CONSTANTS #####
#region

Write-Verbose "Loading constants."

# the amount of time, in minutes, to wait before resetting the $time variable.
# $time is used to reduce the number of events processed. This improves event wait performance.
# Default = 3
# Minimum value = 2
$timeResetDelay = 3

# amount of time, in milliseconds, between scans for new events. 
# Default = 100
# Minimum value = 50
$loopSensitivity = 100

## EVENT LOGS ##
# list of events to collect at the end of tracing
[string[]]$EVENT_LOG_LIST = 'SYSTEM',
                            'Application'

## TRACING PROVIDERS ##
# list of ETW providers to attempt collection from
[string[]]$Script:PROVIDER_LIST =   '{E53C6823-7BB8-44BB-90DC-3F86090D48A6}', # Microsoft-Windows-Winsock-AFD
                                    '{0C478C5B-0351-41B1-8C58-4A6737DA32E3}', # Microsoft-Windows-WFP
                                    '{2F07E2EE-15DB-40F1-90EF-9D7BA282188A}', # Microsoft-Windows-TCPIP
                                    '{eb004a05-9b1a-11d4-9123-0050047759bc}'  # NetIO
                                    

# is LBFO in use
$isLBFO = Get-NetLbfoTeam -EA SilentlyContinue
if ($isLBFO)
{
    # add LBFO providers
    $Script:PROVIDER_LIST += '{B72C6994-9FE0-45AD-83B3-8F5885F20E0E}', # Microsoft-Windows-MsLbfoEventProvider
                             '{B1809D25-B84D-4E40-8D1B-C9978D8946AB}', # LBFOProviderGUID
                             '{A781472C-CFC9-42CB-BCEA-A00B916AD1BE}', # NDISIMPLAT
                             '{DD7A21E6-A651-46D4-B7C2-66543067B869}', # NDISTraceGuid
                             '{9B5CB64B-6166-4369-98CA-986AE578E216}', # NdisImPlatformWPPGuid
                             '{387ED463-8B1B-42C9-9EF0-803FDFD5D94E}'  # Microsoft-Windows-MsLbfoSysEvtProvider

    $EVENT_LOG_LIST +=  'Microsoft-Windows-MsLbfoProvider/Operational'
}

# check for Hyper-V by looking for a vmSwitch
# the same providers work for SET
$isHV = Get-Command Get-VMSwitch -EA SilentlyContinue
if ($isHV)
{
    $isVMSw = Get-VMSwitch -EA SilentlyContinue
    
    if ($isVMSw)
    {
        # add LBFO providers
        $Script:PROVIDER_LIST +=    '{6066F867-7CA1-4418-85FD-36E3F9C0600C}', # Microsoft-Windows-Hyper-V-VMMS
                                    '{7B0EA079-E3BC-424A-B2F0-E3D8478D204B}', # Microsoft-Windows-Hyper-V-VSmb
                                    '{3AD15A04-74F1-4DCA-B226-AFF89085A05A}', # Microsoft-Windows-Wnv
                                    '{1F387CBC-6818-4530-9DB6-5F1058CD7E86}', # vmswitch
                                    '{67DC0D66-3695-47C0-9642-33F76F7BD7AD}', # Microsoft-Windows-Hyper-V-VmSwitch	
                                    '{CA630800-D4D4-4457-8983-DFBBFCAC5542}'  # NFPTraceGuid (VMQ)

        $EVENT_LOG_LIST +=  'Microsoft-Windows-Hyper-V-EmulatedNic-Admin',
                            'Microsoft-Windows-Hyper-V-Hypervisor-Admin',
                            'Microsoft-Windows-Hyper-V-Hypervisor-Operational',
                            'Microsoft-Windows-Hyper-V-SynthNic-Admin',
                            'Microsoft-Windows-Hyper-V-VMMS-Networking',
                            'Microsoft-Windows-Hyper-V-VMMS-Admin',
                            'Microsoft-Windows-Hyper-V-VmSwitch-Operational'
    }
}

## POST-TRACING COMMANDS ##
# list of commands to run after tracing is done
# - strings are treated as the command and file name
# - arrays are treated as ("command", "filename") 
# - arrays with an empty ('' or "") second object assume that the file write is part of the command (see the gpresult command)
[array]$POST_COMMANDS = [array]('Get-NetAdapter | fl *', 'Get-NetAdapter'),
                        'Get-NetIPAddress',
                        'systeminfo',
                        [array]("pushd $dataPath; gpresult /H gpresult.html; popd",''),
                        [array]("tasklist /SVC /FO CSV > '$dataPath\tasklist.csv'",''),
                        [array]('Get-DnsClientCache | fl', 'Get-DnsClientCache')


## Misc ##

$startTS = Get-Date -format "yyyyMMdd_HHmmss_ffff"
# name of the log file
$script:trcLogName = "ClusterTraceLog_$startTS`.log"

# path to the script location
$Script:ScriptPath = Split-Path $MyInvocation.MyCommand.Path -Parent

# where all the data goes
$dataPath = "$tracePath\ClusterTraceData`_$startTS"

$Script:SAVE_PATH = $dataPath
$Script:dataPath = $dataPath

# calculate est. disk usage
# system and application are 15MB each, all other logs are 1MB each
$Script:diskEst = $fileSize + (30 + $EVENT_LOG_LIST.Count - 2)

if ($GetClusLogs)
{
    $Script:diskEst = $Script:diskEst + (150 * $remoteComputer.Count)
}

if ($GetPerfmon)
{
    $Script:diskEst = $Script:diskEst + 300
}

if ($GetNetFT)
{
    $Script:diskEst = $Script:diskEst + 1024
}

# add 20% for compression
$Script:diskEst = $Script:diskEst + ($Script:diskEst * 0.2)

## Local system information ##

# get list of all event logs
$Script:ALL_LOGS = Get-WinEvent -ListLog *

# .NET version
$Script:dotNetVer = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -recurse | Get-ItemProperty -name Version -EA 0 | Where-Object { $_.PSChildName -match '^(?!S)\p{L}'} | Select-Object PSChildName, Version

# OS version
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
[int]$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
[int]$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor

# OS version name
if ($Script:osMajVer -le 5) {
    Write-Error "This is unsupported version of Windows."
    exit
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 0) {
    Write-Error "This is unsupported version of Windows."
    exit
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 1) {
    Write-Error "This is unsupported version of Windows. Please use the legacy script."
    exit
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 2) {
    [string]$Script:osName = "2012"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 3) {
    [string]$Script:osName = "2012R2"
 } elseif ($Script:osMajVer -eq 10) {
    [string]$Script:osName = "10"
 }


# set the script var defEtwLvl to level, if a level was passed, or detect the default ETW level based on OS build
# set the maximum level to 0x5 or 0xff, depending on OS version
switch ($Script:osMajVer) {
    10 
    {
        # set the ETW max level to 0xff
        [byte]$script:maxEtwLvl = 0xff
        
        # now test to make sure it works.
        # make sure there are no existing netevent sessions.
        $netSession = Get-NetEventSession

        if ($netSession) {
            # if the session is stopped simply remove it
            if ($netSession.SessionStatus -ne "Running") {
                $netSession | Remove-NetEventSession
            } else {
                # if it's running prompt to stop
                Write-Warning "There is an existing capture session running. The session must be stopped and removed before continuing.`n`nIf a previous execution of this script was abnormally terminated, which can leave a running capture session, then it should be safe to stop; otherwise, please select No unless you are certain it is safe to stop the existing session."
                Write-Host -ForegroundColor Yellow "`nRemove the existing capture session?`n`nPress 'y' to remove the existing session or 'n' to exit the script."

                # wait for n or y to be pressed
                do {$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")} until ($x.Character -eq 'n' -or $x.Character -eq 'N' -or $x.Character -eq 'y' -or $x.Character -eq 'Y')

                switch ($x.Character) {
                    "N" {exit}
                    "Y" {
                         Get-NetEventSession | Stop-NetEventSession | Out-Null
                         Get-NetEventSession | Remove-NetEventSession | Out-Null
                        }
                    default {exit}
                }

            }
        }

        # create test session
        New-NetEventSession test | Out-Null
        
        # add a provider with 0xff level
        $test = Add-NetEventProvider -Name '{2F07E2EE-15DB-40F1-90EF-9D7BA282188A}' -SessionName test -Level $script:maxEtwLvl -EA SilentlyContinue

        Write-Verbose "Result of max ETl level test: $test"

        if ($Error)
        {
            if ($Error[0].ToString() -match 'method were invalid')
            {
                [byte]$script:maxEtwLvl = 0x5
            }
        }

        Get-NetEventSession | Remove-NetEventSession | Out-Null

        break
    }
    # Windows 8.1\2012 R2 set 0x5
    6 {[byte]$script:maxEtwLvl = 0x5; break}
}

Write-Verbose "Constants loaded."
#endregion

##### FUNCTIONS #####
#region


# FUNCTION: Get-TimeStamp
# PURPOSE: Returns a timestamp string

function Get-TimeStamp 
{
    return "$(Get-Date -format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp


# FUNCTION: Write-Log
# PURPOSE: Writes script information to a log file and to the screen when -Verbose is set.

function Write-Log {
    param ([string]$text, [switch]$tee = $false, [string]$foreColor = $null)

    $foreColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"

    # check the log file, create if missing
    $isPath = Test-Path "$script:dataPath\$script:trcLogName"
    if (!$isPath) {
        "$(Get-TimeStamp): Log started" | Out-File "$script:dataPath\$script:trcLogName" -Force
        "$(Get-TimeStamp): Local log file path: $("$script:dataPath\$script:trcLogName")" | Out-File "$script:dataPath\$script:trcLogName" -Force
        Write-Verbose "Local log file path: $("$script:dataPath\$script:trcLogName")"
    }
    
    # write to log
    "$(Get-TimeStamp): $text" | Out-File "$script:dataPath\$script:trcLogName" -Append

    # write text verbosely
    Write-Verbose $text

    if ($tee)
    {
        # make sure the foreground color is valid
        if ($foreColors -contains $foreColor -and $foreColor)
        {
            Write-Host -ForegroundColor $foreColor $text
        } else {
            Write-Host $text
        }        
    }
} # end Write-Log

# Compress-Directory: Compresses all the files in a dir to a cab file 
function Compress-Directory {
    param ([string]$dir, [string]$cabName, [string]$cabPath)

    Write-Log "Compress-Directory: Start"
    # first see if there is a Compress-Archive cmdlet
    $isCACmd = Get-Command Compress-Archive -EA SilentlyContinue
    if ($isCACmd)
    {
        try 
        {
            Compress-Archive -Path $dir -DestinationPath "$cabPath\$cabName`.zip" -CompressionLevel Optimal -Force -ErrorAction Stop    
        }
        catch 
        {
            Write-Log "Compress-Directory: Failed to compress data using Compress-Archive.`n`r`tSource:`t`t$dir`n`r`tDest:`t`t$cabPath\$cabName`.zip"
        }

        # did it work?
        $didWrk = Get-Item "$cabPath\$cabName`.zip" -EA SilentlyContinue
        if ($didWrk)
        {
            Write-Log "Compress-Directory: Data compressed to $($didWrk.FullName)."
            Write-Log "Compress-Directory: end"
            return $($didWrk.FullName)
        }
    }

    # try using .NET if the right version is installed
    if (($Script:dotNetVer | Where-Object {$_.Version -ge 4.5}))
    {
        try 
        {
            Add-Type -Assembly "System.IO.Compression.FileSystem" -EA Stop
            [System.IO.Compression.ZipFile]::CreateFromDirectory("$dir", "$cabPath\$cabName`.zip") 
        }
        catch 
        {
            Write-Log "Compress-Directory: Failed to compress data using System.IO.Compression.FileSystem.`n`r`tSource:`t`t$dir`n`r`tDest:`t`t$cabPath\$cabName`.zip"
        }

        # did it work?
        $didWrk = Get-Item "$cabPath\$cabName`.zip" -EA SilentlyContinue
        if ($didWrk)
        {
            Write-Log "Compress-Directory: Data compressed to $($didWrk.FullName)."
            Write-Log "Compress-Directory: end"
            return $($didWrk.FullName)
        }
    }
    
    # fall back to cab if everything else fails
    Write-Log "Compress-Directory: Falling back to CAB compression."
    $ddf = ".Set CabinetNameTemplate=$cabName`.cab
.set CompressionType=LZX
.set DiskDirectory=.
.set DiskDirectory1=.
.set Cabinet=on
.set InfFileName=nul
.set RptFileName=nul
.set maxdisksize=0
"
    $dirfullname = (get-item $dir).fullname
    $ddfpath = ($env:TEMP+"\temp.ddf")
    $ddf += (Get-ChildItem -recurse $dir | Where-Object {!$_.psiscontainer} | Select-Object -expand fullname | ForEach-Object {'"'+$_+'" "'+$_.SubString($dirfullname.length+1)+'"'}) -join "`r`n"
    
    $ddf | Out-File -encoding UTF8 $ddfpath

    Push-Location "$cabPath"
    makecab /F $ddfpath /L $cabPath
    Remove-Item $ddfpath
    Pop-Location

    Write-Log "Compress-Directory: returning $cabPath\$cabName`.cab"
    Write-Log "Compress-Directory: end"
    return "$cabPath\$cabName`.cab"
}


# Start-NetFtTrace: Starts NetFT tracing using the logman method.
function Start-NetFtTrace {

    param ($tracePath = "C:\")

    Write-Log "Start-NetFtTrace: Start"
    Invoke-Expression "logman create trace `"base_cluster`" -ow -o `"$tracePath\base_cluster.etl`" -p '{7E66368D-B895-45F2-811F-FB37940421A6}' 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 1024 -ets | Write-Log"
    Write-Log "Start-NetFtTrace: End"
} # end Start-NetFtTrace


# Stop-NetFtTrace: Stops NetFT tracing using the logman method.
function Stop-NetFtTrace {
    Write-Log "Stop-NetFtTrace: Start"
    Logman stop base_cluster -ets | Write-Log
    Write-Log "Stop-NetFtTrace: End"
}

# Start-GetPerfmon: Starts Perfmon tracing using the logman method.
function Start-GetPerfmon {

    param ($tracePath = "C:\")
    
    Write-Log "Start-GetPerfmon: Start"
    Invoke-Expression "logman create counter `"base_perfmon`" -o `"$tracePath\base_perfmon.blg`" -f bincirc -v mmddhhmm -max 300 -c `"\LogicalDisk(*)\*`" `"\Memory\*`" `"\.NET CLR Memory(*)\*`" `"\Cache\*`" `"\Network Interface(*)\*`" `"\Netlogon(*)\*`" `"\Paging File(*)\*`" `"\PhysicalDisk(*)\*`" `"\Processor(*)\*`" `"\Processor Information(*)\*`" `"\Process(*)\*`" `"\Thread(*)\*`" `"\Redirector\*`" `"\Server\*`" `"\System\*`" `"\Server Work Queues(*)\*`" `"\Terminal Services\*`" -si 00:00:01 | Write-Log"
    Invoke-Expression "logman start `"base_perfmon`" | Write-Log"
    Write-Log "Start-GetPerfmon: End"
} # end Start-GetPerfmon

# Stop-GetPerfmon: Stops Perfmontracing using the logman method.
function Stop-GetPerfmon {
    Write-Log "Stop-GetPerfmon: Start"
    Logman stop base_perfmon | Write-Log
    Logman delete base_perfmon | Write-Log
    Write-Log "Stop-GetPerfmon: Start"
}	

# FUNCTION: New-Folder
# PURPOSE: Given a path, test whether the path is a) valid, b) exists, and c) create the path if it does not and is valid

function New-Folder
{
    param ($path)

    Write-Log "New-Folder: Start"
    # check whether the path is a string or a file system object. convert to string path if file system object
    if ($path -is [System.IO.FileSystemInfo])
    {
        $path = $path.FullName.toString()
    }
    elseif ($path -isnot [string]) 
    {
        Write-Log "New-Folder: ERROR! New-Folder destination can only be a System.String or System.IO.FileSystemInfo data type."
        return $false
    }

    # make sure the patth is valid
    $isValid = Test-Path $path -IsValid
    if (!$isValid) 
    {
        Write-Log "New-Folder: ERROR! The path is invalid - $path"
        return $false
    }

    # test whether the path already exists
    $isFnd = Test-Path $path
    if (!$isFnd)
    {
        Write-Log "Creating directory: $path"
        try {
            New-Item -Path $path -ItemType Directory -Force -EA Stop | Out-Null
        }
        catch {
            Write-Log "New-Folder: ERROR! Data path was not found and could not be created: $path `n$($Error[0].toString())"
            return $false
        }
    }

    Write-Log "New-Folder: End"
    return $true
} #end New-Folder



# FUNCTION: Copy-Log
# PURPOSE: Finds and copies an event log EVTX based on the log name.

function Copy-Log 
{
    [CmdletBinding()]
    param ([string]$logName, $destination)

    Write-Log "Copy-Log: Start"
    # validate the destination path
    if ($destination -is [System.IO.FileSystemInfo]) {
        [string]$destination = $($destination.FullName)
    } elseif ($destination -isnot [string]) {
        Write-Log "Copy-Log: ERROR! Copy-Log destination can only be a System.String or System.IO.FileSystemInfo data type."
        return $false
    }

    # make sure the log name is valid
    $tmpEvt = Get-WinEvent -ListLog $logName -EA SilentlyContinue
    if (!$tmpEvt) {
        Write-Log "Copy-Log: WARNING! Log not found - $logName."
        return $false
    } else {
        # get the log path, in PowerShell format, of the log
        $logPath = (Get-WinEvent -ListLog $logName).LogFilePath -replace [regex]::Escape('%SystemRoot%'), "$ENV:SystemRoot"
    }

    # set error action so try-catch works
    $ErrorActionPreference = "Stop"

    # try to copy the log file
    Try {
        Copy-Item $logPath $destination -Force
    } catch {
        Write-Log "Copy-Log: WARNING! Log file not found for $logName."
        return $false
    } 
    
    Write-Log "Copy-Log: Log file for $logName was successfuly copied."
    Write-Log "Copy-Log: End"
    return $true
    
} # end Copy-Log


# FUNCTION: Copy-File
# PURPOSE: Copies a file to the dataPath

function Copy-File 
{
    param ($file, $dataPath)

    Write-Log "Copy-File: Start"

    # make sure something is passed in
    if ($file -eq '' -or $null -eq $file)
    {
        Write-Log "Copy-File: ERROR! No files were sent to Copy-File."
        return $false
    }

    # validate the destination path
    if ($dataPath -is [System.IO.FileSystemInfo]) {
        [string]$dataPath = $($dataPath.FullName)
    } elseif ($dataPath -isnot [string]) {
        Write-Log "Copy-File: ERROR! Copy-Log destination can only be a System.String or System.IO.FileSystemInfo data type."
        return $false
    }

    # test whether the file exists
    $isFileFnd = Test-Path $file -EA SilentlyContinue
    if (!$isFileFnd -and $file -notmatch '*') {
        Write-Log "Copy-File: ERROR! File not found: $file"
        return $false
    }

    # double check the dataPath, create if does not exist
    $isPathFnd = New-Folder $dataPath

    # finally, copy the file
    if ($isPathFnd)
    {
        Write-Log "Copy-File: Attempting file copy from $file to $dataPath`."
        try 
        {
            Copy-Item $file $dataPath -Force -EA Stop | Out-Null
        }
        catch
        {
            Write-Log "Copy-File: File copy from $file to $dataPath failed - `n$($Error[0].toString())"
            return $false
        }
    }

    Write-Log "Copy-File: End"
    return $true

} # end Copy-File


# FUNCTION: Start-Command
# PURPOSE: Run a command and save the output to dataPath

function Start-Command 
{
    param ([array]$commands, $dataPath)

    Write-Log "Start-Command: Start"
    # double check the dataPath, create if does not exist
    $isPathFnd = New-Folder $dataPath
    
    if ($isPathFnd)
    {
        # loop through commands
        foreach ($command in $commands) {
            # run the command and output to the data path
            if ($command -is [array]) {
                if ($command[1] -eq '' -or $command[1] -eq "" -or $null -eq $command[1]) {
                    Write-Log "Start-Command: Invoking command - $($command[0])"
                    Invoke-Expression "$($command[0])"
                } else {
                    if ($command[1] -match ".csv")
                    {
                        Write-Log "Start-Command: Invoking command - $($command[0]) | Export-CSV `"$dataPath\$($command[1])`" -Force"
                        Invoke-Expression "$($command[0]) | Export-CSV `"$dataPath\$($command[1])`" -NoTypeInformation -Force"
                    } else {
                        Write-Log "Start-Command: Invoking command - $($command[0]) | Out-File `"$dataPath\$($command[1])`.txt`" -Force"
                        Invoke-Expression "$($command[0]) | Out-File `"$dataPath\$($command[1])`.txt`" -Force"
                    }
                    
                }
            } else {
                Write-Log "Invoking command: $command | Out-File `"$dataPath\$command`.txt`" -Force"
                Invoke-Expression "$command | Out-File `"$dataPath\$command`.txt`" -Force"
            }
        }
    }
    Write-Log "Start-Command: Start"
} # end Start-Command



# FUNCTION: Start-Log
# PURPOSE: Tests whether an event log is stopped, and starts if it is not

function Start-Log 
{
    param ([string[]]$logName)

    Write-Log "Start-Log: Start"
    foreach ($log in $logName) {
        # make sure the log name exists
        if ($Script:ALL_LOGS.LogName -notcontains $log) {
            Write-Log "Start-Log: Log not found - $log"
        } else {

            # check if the log is already enabled
            if (($Script:ALL_LOGS | Where-Object LogName -EQ $log).IsEnabled) {
                Write-Log "Start-Log: $log is enabled."
            } else {

                # enable the log
                Write-Log "Start-Log: Start logging for $log."
                $tmp = $Script:ALL_LOGS | Where-Object LogName -EQ $log
                $tmp.isEnabled = $true
                $tmp.MaximumSizeInBytes = $(50MB)
                $tmp.SaveChanges()

                # record the log name
                $Script:Started_Logs += $log
            }
        }
    }

    Write-Log "Start-Log: End"

} # end Start-Log



# FUNCTION: Stop-Log
# PURPOSE: Tests whether an event log is started, and stops if it is not

function Stop-Log 
{
    param ([string[]]$logName)

    Write-Log "Stop-Log: Start"
    foreach ($log in $logName) {
        # disable the log
        Write-Log "Stop-Log: Stop logging for $log."
        $tmp = $Script:ALL_LOGS | Where-Object LogName -EQ $log
        if ($tmp) {
            $tmp.isEnabled = $false
            $tmp.SaveChanges()
        } else {
            Write-Log "Stop-Log: WARNING! Could not stop logging for $log."
        }
    }
    Write-Log "Stop-Log: End"
} # end Stop-Log


# FUNCTION: Add-Providers
# PURPOSE: Adds ETW providers to a NetEventPacketCapture session.
 
function Add-Providers 
{
    # $cap = capture session or session name
    # $level = capture level for the provider. Level 0x4 is used when no level is passed.
    # $providers = Array of the providers to add to the session.
    param ($cap,
            $level,
            [array]$providers)
    
    Write-Log "Add-Providers: Start"
    # set error action so try-catch works
    $ErrorActionPreference = "Stop"

    # ensure $cap is a valid NetEventSession, if a string is passed instead of a NetEventSession
	if ($cap -isnot [CimInstance] -and $cap.CimCLass -ne 'root/StandardCimv2:MSFT_NetEventSession') {
        try {
            $cap =  Get-NetEventSession -Name $cap
        } catch [Microsoft.PowerShell.Cmdletization.Cim.CimJobException] {
            Write-Log "Add-Providers: NetEventSession $cap could not be found." -tee -foreColor Red
            return $false
        }
    }

    # make sure provider list only contains unique GUIDs
    #$providers = $providers | Sort-Object -Unique    <<<< this is messing with hashtables. Need to rethink this for a mix of hashtable and string values
    $tmpStrPrvdr = $providers | Where-Object {$_ -is [string]} | Sort-Object -Unique
    $tmpHshPrvdr = $providers | Where-Object {$_ -is [hashtable]} # | Sort-Object -Property Provider -Unique  <<<< the unique op breaks hashtable sorting
    $providers = $tmpStrPrvdr 
    $providers +=  $tmpHshPrvdr

    ## add the ETW providers
    foreach ($provider in $providers) {
        # test whether the provider is a string...
        if ($provider -is [string])
        {
            $providerName = $provider
            $keyWords = "0xFFFFFFFFFFFFFFFF"
        
        # ...or a hashtable...
        } elseif ($provider -is [hashtable])
        {
            # @{provider='{}'; level=""; keywords=""}
            $providerName = $provider.provider
            
            ## set and test custom level
            $level = $provider.level

            try 
            {
                [byte]$level | Out-Null
            } catch
            {
                Write-Log "Add-Providers: Invlaid level, setting to default: `n`rprovider=$providerName `n`rlevel=$level `n`rerror=$($Error[0].ToString())`n`r"
                $level = $script:defEtwLvl
            }

            # make sure the level is not out of bounds
            if ([byte]$level -gt [byte]$script:maxEtwLvl)
            {
                Write-Log "Add-Providers: Level $level is out of bounds for this OS. Setting $providerName to max etw lvl of $script:maxEtwLvl`."
                [byte]$level = [byte]$script:maxEtwLvl
            }

            # set and test custom keywords
            $keyWords = $provider.keywords
            try 
            {
                [uint64]$keyWords | Out-Null
            } catch
            {
                Write-Log "Add-Providers: Invlaid keywords, setting to default: `n`rprovider=$providerName `n`rkeyWords=$keyWords `n`rerror=$($Error[0].ToString())`n`r"
                $keyWords = "0xFFFFFFFFFFFFFFFF"
            }

        # ...or unknown.
        } else 
        {
            Write-Log "Add-Providers: Invalid provider: $($provider)"
            $providerName = $null
        }

        # add the provider
        if ($providerName)
        {
            Write-Log "Add-Providers: Adding provider $providerName`: level=$($level) keywords=$($keyWords)"
            
            try {
                Add-NetEventProvider -SessionName $cap.Name -Name $providerName -Level $level -MatchAnyKeyword $keyWords | Out-Null
            } catch {
                Write-Log "Add-Providers: Could not add provider $providerName`. `n`rerror=$($Error[0].ToString())`n`r"
            }
        }
    }

    Write-Log "Add-Providers: End"
    return $true
} # end Add-Providers


# FUNCTION: Start-Trace
# PURPOSE: Collect a network trace based on OS version.
# 2008/2003: Unsupported
# 2008 R2/2012: netsh trace
# 2012 R2+: NetEventPacketCapture

<# past commands:
# netsh trace start scenario=NetConnection maxSize=$fileSize capture=yes report=no correlation=no overwrite=yes tracefile="$Script:SAVE_PATH\$filename"
netsh trace start scenario=NetConnection maxSize=$fileSize capture=yes report=no correlation=no overwrite=yes tracefile="$Script:SAVE_PATH\$filename"

# packets no scenario
netsh trace start maxSize=$fileSize capture=yes report=no correlation=no overwrite=yes tracefile="$Script:SAVE_PATH\$filename" | Out-Null

# capture UDP only version of command
netsh trace start capture=yes Protocol=17 report=no correlation=no overwrite=yes tracefile="$Script:SAVE_PATH\$filename"

#>
function Start-Trace {
    param (
        # New-NetEventSession options
        $name,
        $CaptureMode,
        $traceFile,
        $maxSize,
        $TraceBufferSize,
        $MaxNumberOfBuffers,

        # Add-NetEventPacketCaptureProvider options
        $udpOnly,
        $capLevel,
        $captureType,
        $truncBytes,

        # Add-NetEventNetworkAdapter options
        $traceNic,
        $PromiscuousMode,

        # Add-Provider options
        $scenarios,
        $PROVIDER_LIST,

        # misc options
        $noCapture = $false
    )

    Write-Log "Start-Trace: Start"
    switch -Regex ($Script:osName) {

        "^2012$" {
            Write-Log "Start-Trace: Using netsh trace."
             ## add selected NICs
            if ($traceNIC -ne "" -and $null -ne $traceNIC) {
                Write-Log "Start-Trace: Filtering by NIC."
                $ntrcNICs = ""
                # get netsh interface list
                $netshNICs = netsh trace show interfaces
                
                $first = $true
                foreach ($nic in $traceNIC) {
                    # find the description of the nic
                    $nicDesc = Get-WmiObject Win32_NetworkAdapter | Where-Object {$_.NetConnectionID -eq $nic} | ForEach-Object {$_.Name}

                    # find the index of the NIC description  in the netshNIC output
                    $idx = 0
                    0..($netshNICs.Count - 1) | ForEach-Object{if ($netshNICs[$_] -like "*$nicDesc*") {$idx = $_ + 1}}

                    # get the GUID of the NIC
                    $tmpGUID = ($netshNICs[$idx].trim(" ").split(" ")[-1]) #.Replace('{','`{').Replace('}','`}')

                    ## add the NIC(s) to the netsh trace command
                    # check for more than 1 NIC
                    if ($traceNIC.Count -gt 1) {
                        # add start string if this is the first NIC in the array
                        if ($first) {
                            $ntrcNICs += "CaptureInterface=("+$tmpGUID
                            $first = $false
                        } else {
                        # add subsequent NICs
                            $ntrcNICs += ",$tmpGUID"
                        }
                    } else {
                        # add a single NIC
                        $ntrcNICs += " CaptureInterface=$tmpGUID "
                    }

                }
                # complete the string for more than 1 NIC
                if ($traceNIC.Count -gt 1) {
                    $ntrcNICs += ')'
                }
            }

            # finish base command
            #$baseNetsh += " maxSize=$fileSize report=no correlation=no overwrite=yes tracefile=`"$Script:SAVE_PATH\$filename`"" 

            ## add the ETW providers
            # list of providers on the system
            Write-Log "Start-Trace: Copllecting a list of providers on the system."
            $ALL_PROVIDERS = netsh trace show providers

            if ($Script:PROVIDER_LIST) {
                Write-Log "Start-Trace: Adding ETW providers."
                $ntrcProv = ""
                foreach ($provider in $Script:PROVIDER_LIST) {
                    if (($ALL_PROVIDERS | Where-Object {$_ -match $provider})) {
                        Write-Log "Start-Trace: Adding provider $provider"
			            #$provider = $provider.Replace('{','`{').Replace('}','`}')
                        $ntrcProv += ' provider='+$provider+' keywords=0xffffffff level=0xff'
                    } else {
                        Write-Log "Start-Trace: Could not find provider $provider"            
                    }
                }
            }
            
            # start the trace
            Write-Log "Start-Trace: Starting the netsh trace"
            #Write-Log "netsh trace start capture=yes $ntrcNICs protocol=17 PacketTruncateBytes=$truncLenB maxSize=$fileSize report=no correlation=no overwrite=yes tracefile=`"$Script:SAVE_PATH\$filename`" $ntrcProv"
            $netArgs = "netsh trace start"

            if ($noCapture)
            {
                $netArgs += " capture=no"
            }
            else 
            {
                $netArgs += " capture=yes $ntrcNICs"

                if ($udpOnly)
                {
                    $netArgs += " protocol=17"
                }
            
                $netArgs += " PacketTruncateBytes=$truncBytes"
            }
            
            $netArgs += " maxSize=$maxSize report=dis correlation=no overwrite=yes tracefile=`"$traceFile`" $ntrcProv"

            
            
            $netArgs = $netArgs.Replace('{','`{').Replace('}','`}').Replace(',','`,').Replace('(','`(').Replace(')','`)')

            Write-Log "Start-Trace: Yee olde giant command:`n`r`n`r$netArgs"

            Invoke-Expression "$netArgs" -Verbose

            Write-Log "Start-Trace: End"
            return $true
        }

        "2012R2|10" {

            Write-Log "Start-Trace: Using PowerShell NetEventPacketCapture."
            Write-Log "Start-Trace: Creating capture session."
            try {
                $cap = New-NetEventSession -Name "$name" -CaptureMode $CaptureMode -LocalFilePath "$traceFile" -MaxFileSize $maxSize -TraceBufferSize $TraceBufferSize -MaxNumberOfBuffers $MaxNumberOfBuffers -EA SilentlyContinue
            }
            catch {
                Write-Log "Start-Trace: Could not create the NetEventSession."
                return $null
            }
        
            # add the packet capture provider
            if (!$noCapture)
            {        
                Write-Log "Start-Trace: Adding packet capture."
                try {
                    # add the packet capture provider
                    if ($udpOnly)
                    {
                        Add-NetEventPacketCaptureProvider -SessionName $name -Level $capLevel -CaptureType $captureType -TruncationLength $truncBytes -IpProtocols 17 -EA SilentlyContinue | Out-Null
                    } else {
                        Add-NetEventPacketCaptureProvider -SessionName $name -Level $capLevel -CaptureType $captureType -TruncationLength $truncBytes -EA SilentlyContinue | Out-Null
                    }
                }
                catch {
                    Write-Log "Start-Trace: Packet capture could not be added to the NetEventSession. Trace is continuing in case the ETW data is sufficient to troubleshoot the issue."
                }
        
                # check whether the trace is running
                if ((Get-NetEventPacketCaptureProvider).Name -eq $name) {
                    Write-Log "Start-Trace: Packet capture successfully added."
                }
            } else {
                Write-Log "Start-Trace: NoCapture set. Add-NetEventPacketCaptureProvider skipped."
            }
        
            # set the capture interface
            if ($traceNic -and $PromiscuousMode) {
                foreach ($nic in $traceNIC) {
                    try {
                        Add-NetEventNetworkAdapter $nic -PromiscuousMode -EA SilentlyContinue | Out-Null
                    }
                    catch {
                        Write-Log "Start-Trace: Failed to add the network adapter with PromiscuousMode to the NetEventSession."
                    }
                }
            } elseif ($traceNic) {
                foreach ($nic in $traceNIC) {
                    try {
                        Add-NetEventNetworkAdapter $nic -EA SilentlyContinue | Out-Null
                    }
                    catch {
                        Write-Log "Start-Trace: Failed to add the network adapters to the NetEventSession."
                    }
                }
            }
        
            
            # add the ETW providers
            if ($cap -is [CimInstance] -and $cap.CimCLass -match 'MSFT_NetEventSession') {
                
                # add providers from scenarios
                if ($scenarios) {
        
                    foreach ($scen in $scenarios) {
        
                        # List of found scenarios
                        # MUST BE CALLED BEFORE EACH ITERATION OF Convert-WppScenario TO PREVENT A FUNCTION RECURSION LOOP!!!
                        $script:foundScenario = @()
        
                        $PROVIDER_LIST += (Convert-WppScenario $scen).'Provider Guid'
        
                    }
                }
                
                $result = Add-Providers -cap $cap -level $script:defEtwLvl -providers $PROVIDER_LIST
        
                if ($result) {
                    Write-Log "Start-Trace: Stack providers added as shown above."   
                } else {
                    Write-Log "Start-Trace: Critical failure adding stack providers."
                }
            } else {
                Write-Log "Start-Trace: Failure creating the NetEventSession."
                Start-Sleep 3
                exit
            }
        
            Write-Log "Start-Trace: Starting capture."
            Start-NetEventSession $name
        
            Write-Log "Start-Trace: End"
            return $cap
        }
        
        # return false for any unsupported scenario
        Unsupported 
        {
            Write-Log "Start-Trace: End"
            return $false
        }

        default 
        {
            Write-Log "Start-Trace: End"
            return $false
        }
    }

    Write-Log "Start-Trace: End"
    return $false
} # end Start-Trace


# FUNCTION: Stop-Trace
# PURPOSE: Stop the network trace

function Stop-Trace {
    param (
        $cap
    )

    Write-Log "Stop-Trace: Start"
    switch -Regex ($Script:osName) {
        "2008R2|^2012$" 
        { 
            # stop netsh trace
            Write-Log "Stop-Trace: Stop netsh trace."
            netsh trace stop

            <#
            if ($filename) {
                $fileBase = ($filename -split '.')[0]
                netsh trace correlate "$Script:SAVE_PATH\$filename" "$Script:SAVE_PATH\$fileBase`_corr.etl" | Out-Null
                Remove-Item "$Script:SAVE_PATH\$filename" -Force | Out-Null
                Rename-Item "$Script:SAVE_PATH\$fileBase`_corr.etl" "$Script:SAVE_PATH\$filename"
            }#>
            Write-Log "Stop-Trace: End"
            return $true
        }
        "2012R2|10" 
        {
            Write-Log "Stop-Trace: Stop NetEventPacketCapture."
            # stop NetEventSession
            Stop-NetEventSession -Name $cap.Name | Out-Null
            # remove NetEventSession
            Remove-NetEventSession -Name $cap.Name | Out-Null
            return $true
        }
        # return false for any unsupported scenario
        default 
        {
            Write-Log "Stop-Trace: End @default"
            return $false
        }
    }
} # end Stop-Trace



#endregion

##### INPUT VALIDATION #####
#region

# create the dir where data goes
if (-NOT (Test-Path "$dataPath")) { New-Item $dataPath -ItemType Directory -Force | Out-Null }

# set asTask to true when taskRestart is set, but -asTask and -Clean are not (-clean is only used by the start task)
if ($taskRestart -and !$asTask -and !$clean)
{
    $asTask = $true
}

# fail if there are no remote computers
if ($null -eq $remoteComputer -or $remoteComputer -eq "")
{
    Write-Log "ERROR: No cluster nodes were found." -foreColor Red -tee
    Start-Sleep 5
    exit
}

# fail when there is no in-box packet capture ability (<Win7)
if (!$skipValidation) {
    Write-Log '"Verifying Windows is version 6.2+...'
    # verify you're running at least Windows version 6.1
    if (($osMajVer -eq 6 -and $osMinVer -lt 2) -or $osMajVer -lt 6) {
        Write-Log "WARNING: You must be running Windows Server 2012 or greater." -foreColor Red -tee
        exit
    }

    # make sure we are running as administrator
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal( [Security.Principal.WindowsIdentity]::GetCurrent() )

    # change the title according to whether the console is running as the admin or the user
    if (!$currentPrincipal.IsInRole( [Security.Principal.WindowsBuiltInRole]::Administrator )) {
        Write-Log "ERROR: You must run this script in an elevated PowerShell console (Run as administrator)." -foreColor Red -tee
        exit
    }


    ## make sure trace path is valid and exists
    if (test-path $tracePath -IsValid) {
        if (!(test-path $tracePath)) {New-Folder $tracePath}
    } else {
        Write-Log "ERROR! $tracePath is an invalid location. Please correct and try again." -foreColor Red -tee
    }

    # make sure there are the same number of event IDs and log names
    if ($logName -and $eventID) {
        if (!($logName.count -gt 0 -and $eventID.count -eq $logName.count)) {
            Write-Log "ERROR! You must have one log name per event ID.`n`r`tlogName: $logName`n`r`teventID: $eventID`n`r`tprovider: $provider" -foreColor Red -tee
            exit
        }
    } else {
        Write-Log "ERROR! You must enter at least one log name and event ID." -foreColor Red -tee
        exit
    }

    # if tracePath is empty, prompt.
    if ($tracePath -eq "" -or $tracePath -eq $null) {
        [string]$tracePath = (Read-Host "Where do you want to save the files")
    }

    # if remoteComputer is empty and there is a nodes file, prompt.
    if ($remoteComputer -eq "" -or $null -eq $remoteComputer) 
    {
        [String[]]$remoteComputer = $(if ($file -ne "" -and $fileSize -eq $null) {
                                        Get-Content "$file"
                                      } else {
                                        $tmpNodes = @()
                                        $count = 1
                                        Write-Log "Enter the hostname of the cluster nodes (enter ! to quit):"
                                        do {
                                            $temp = Read-Host "Node`[$count`]"
                                            if ($temp -ne "" -and $temp -ne '!') {
                                                $tmpNodes += $temp
                                                $count++
                                            }
                                        } until ($temp -eq "" -or $temp -eq '!')
                                        $tmpNodes
                                    })
    }

    # make sure .NET 3.5 is installed.
    if (!($Script:dotNetVer | Where-Object {$_.Version -ge 3.5})) {
        Write-Log "ERROR! You must have .NET Framework 3.5 or greater installed. Script is terminating." -foreColor Red -tee
        Start-Sleep 8
        exit
    }
}

# set $timeResetDelay to 2 minutes, in case someone sets the delay to an unsupported value
if ($timeResetDelay -lt 2) {$timeResetDelay = 2}

# set $loopSensitivity to 50ms, in case someone sets the delay to an unsupported value
if ($loopSensitivity -lt 50) {$loopSensitivity = 50}


#endregion


##### SCRIPT MAIN #####

Write-Log "Estimated maximum disk usage = $Script:diskEst MB `($([math]::Round($Script:diskEst/1024, 2)) GB`)" -tee

### AsTask ###
# create a SYSTEM task to execute the script if -asTask is set
if ($asTask) {
    
    Write-Log "Running asTask."
    ## get domain admin credentials for starting the cluster trace task.
    Write-Log "Enter credentials with Administrator rights on ALL cluster nodes." -foreColor Yellow -tee
    # use an encoded command to collect and save credentials in an encrypted format in a more secure location
    powershell -NoProfile -EncodedCommand CgAgACAAIAAgACQAYwByAGUAZABzACAAPQAgACgARwBlAHQALQBDAHIAZQBkAGUAbgB0AGkAYQBsACkACgAKACAAIAAgACAAIwAgAGUAeABpAHQAIABpAGYAIABhACAAUABTAEMAcgBlAGQAZQBuAHQAaQBhAGwAIABvAGIAagBlAGMAdAAgAGkAcwAgAG4AbwB0ACAAcABhAHMAcwBlAGQACgAgACAAIAAgAGkAZgAgACgAJABjAHIAZQBkAHMAIAAtAGkAcwBuAG8AdAAgAFsAUwB5AHMAdABlAG0ALgBNAGEAbgBhAGcAZQBtAGUAbgB0AC4AQQB1AHQAbwBtAGEAdABpAG8AbgAuAFAAUwBDAHIAZQBkAGUAbgB0AGkAYQBsAF0AKQAgAHsACgAgACAAIAAgACAAIAAgACAAQwBsAG8AcwBlAC0AVwBpAHQAaABFAHIAcgBvAHIAIAAiAEkAbgB2AGEAbABpAGQAIABjAHIAZQBkAGUAbgB0AGkAYQBsAHMALgAgAE0AdQBzAHQAIABwAGEAcwBzACAAYQAgAFAAUwBDAHIAZQBkAGUAbgB0AGkAYQBsACAAbwBiAGoAZQBjAHQAIAAoAEcAZQB0AC0AQwByAGUAZABlAG4AdABpAGEAbAApACIACgAgACAAIAAgAH0ACgAKACAAIAAgACAAIwAgAHMAdABhAHQAaQBjACAAcABhAHQAaAAgAHQAbwAgAHQAaABlACAAYwByAGUAZABlAG4AdABpAGEAbABzACAAaABhAHMAaAAgAGYAaQBsAGUACgAgACAAIAAgACQAcABhAHQAaAAgAD0AIAAiACQARQBOAFYAOgB3AGkAbgBkAGkAcgBcAHQAZQBtAHAAXABzAGMAcgBpAHAAdAAuAGgAYQBzAGgAIgAKAAoAIAAgACAAIAAjACAAZwBlAG4AZQByAGEAdABlACAAdABoAGUAIABrAGUAeQAgAHUAcwBpAG4AZwAgAGEAIABoAGEAcwBoACAAcwBvACAAaQB0ACcAcwAgAGEAbAB3AGEAeQBzACAAdABoAGUAIABzAGEAbQBlACwAIAB3AGkAdABoAG8AdQB0ACAAdwByAGkAdABpAG4AZwAgAGEAbgB5AHQAaABpAG4AZwAgAHQAbwAgAGYAaQBsAGUACgAgACAAIAAgACQAZQBuAGMAIAA9ACAAWwBzAHkAcwB0AGUAbQAuAFQAZQB4AHQALgBFAG4AYwBvAGQAaQBuAGcAXQA6ADoAQQBTAEMASQBJAAoAIAAgACAAIABbAHMAdAByAGkAbgBnAF0AJABzAHQAcgBpAG4AZwAxACAAPQAgACcAOABNAHAAcQB6ADAAagAxAE8ANABkAGgAUQBBADIAMwAnACAAIAAgAAoAIAAgACAAIAAkAGgAYQBzAGgAZQByACAAPQAgAG4AZQB3AC0AbwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAuAFMAZQBjAHUAcgBpAHQAeQAuAEMAcgB5AHAAdABvAGcAcgBhAHAAaAB5AC4AUwBIAEEAMgA1ADYATQBhAG4AYQBnAGUAZAAKACAAIAAgACAAJAB0AG8ASABhAHMAaAAgAD0AIABbAFMAeQBzAHQAZQBtAC4AVABlAHgAdAAuAEUAbgBjAG8AZABpAG4AZwBdADoAOgBVAFQARgA4AC4ARwBlAHQAQgB5AHQAZQBzACgAJABzAHQAcgBpAG4AZwAxACkACgAgACAAIAAgACQAUwBlAGMAdQByAGUASwBlAHkAIAA9ACAAJABoAGEAcwBoAGUAcgAuAEMAbwBtAHAAdQB0AGUASABhAHMAaAAoACQAdABvAEgAYQBzAGgAKQAKAAoAIAAgACAAIAAjACAAYwBvAG4AdgBlAHIAdAAgAHUAcwBlAHIALAAgAGQAbwBtAGEAaQBuACwAIABhAG4AZAAgAHAAYQBzAHMAIAB0AG8AIABzAGUAYwB1AHIAZQBzAHQAcgBpAG4AZwAgAGEAbgBkACAAZQB4AHAAbwByAHQAIAB0AG8AIABmAGkAbABlAAoAIAAgACAAIABbAHMAdAByAGkAbgBnAF0AJAB1AHMAZQByACAAPQAgACQAYwByAGUAZABzAC4ARwBlAHQATgBlAHQAdwBvAHIAawBDAHIAZQBkAGUAbgB0AGkAYQBsACgAKQAuAFUAcwBlAHIATgBhAG0AZQAKACAAIAAgACAAJABlAG4AYwBVAHMAZQByACAAPQAgACQAdQBzAGUAcgAgAHwAIABDAG8AbgB2AGUAcgB0AFQAbwAtAFMAZQBjAHUAcgBlAFMAdAByAGkAbgBnACAALQBBAHMAUABsAGEAaQBuAFQAZQB4AHQAIAAtAEYAbwByAGMAZQAKACAAIAAgACAAJABlAG4AYwBVAHMAZQByACAAfAAgAEMAbwBuAHYAZQByAHQARgByAG8AbQAtAFMAZQBjAHUAcgBlAFMAdAByAGkAbgBnACAALQBrAGUAeQAgACQAUwBlAGMAdQByAGUASwBlAHkAIAB8ACAATwB1AHQALQBGAGkAbABlACAAJABwAGEAdABoAAoACgAgACAAIAAgAGkAZgAgACgAJABjAHIAZQBkAHMALgBHAGUAdABOAGUAdAB3AG8AcgBrAEMAcgBlAGQAZQBuAHQAaQBhAGwAKAApAC4ARABvAG0AYQBpAG4AIAAtAG4AZQAgACIAIgApACAAewAKACAAIAAgACAAIAAgACAAIABbAHMAdAByAGkAbgBnAF0AJABkAG8AbQBhAGkAbgAgAD0AIAAkAGMAcgBlAGQAcwAuAEcAZQB0AE4AZQB0AHcAbwByAGsAQwByAGUAZABlAG4AdABpAGEAbAAoACkALgBEAG8AbQBhAGkAbgAKACAAIAAgACAAIAAgACAAIAAkAGUAbgBjAEQAbwBtAGEAaQBuACAAPQAgACQAZABvAG0AYQBpAG4AIAB8ACAAQwBvAG4AdgBlAHIAdABUAG8ALQBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwAgAC0AQQBzAFAAbABhAGkAbgBUAGUAeAB0ACAALQBGAG8AcgBjAGUACgAgACAAIAAgACAAIAAgACAAJABlAG4AYwBEAG8AbQBhAGkAbgAgAHwAIABDAG8AbgB2AGUAcgB0AEYAcgBvAG0ALQBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwAgAC0AawBlAHkAIAAkAFMAZQBjAHUAcgBlAEsAZQB5ACAAfAAgAE8AdQB0AC0ARgBpAGwAZQAgACQAcABhAHQAaAAgAC0AQQBwAHAAZQBuAGQACgAgACAAIAAgAH0ACgAgACAAIAAgAAoAIAAgACAAIABbAHMAdAByAGkAbgBnAF0AJABwAGEAcwBzACAAPQAgACQAYwByAGUAZABzAC4ARwBlAHQATgBlAHQAdwBvAHIAawBDAHIAZQBkAGUAbgB0AGkAYQBsACgAKQAuAFAAYQBzAHMAdwBvAHIAZAAKACAAIAAgACAAJABlAG4AYwBQAGEAcwBzACAAPQAgACQAcABhAHMAcwAgAHwAIABDAG8AbgB2AGUAcgB0AFQAbwAtAFMAZQBjAHUAcgBlAFMAdAByAGkAbgBnACAALQBBAHMAUABsAGEAaQBuAFQAZQB4AHQAIAAtAEYAbwByAGMAZQAKACAAIAAgACAAJABlAG4AYwBQAGEAcwBzACAAfAAgAEMAbwBuAHYAZQByAHQARgByAG8AbQAtAFMAZQBjAHUAcgBlAFMAdAByAGkAbgBnACAALQBrAGUAeQAgACQAUwBlAGMAdQByAGUASwBlAHkAIAB8ACAATwB1AHQALQBGAGkAbABlACAAJABwAGEAdABoACAALQBBAHAAcABlAG4AZAAKAAoAIAAgACAAIAByAGUAdAB1AHIAbgAgACQAdAByAHUAZQAKAA==
    
    # create a hashtable of all parameters
    Write-Log "Parsing parameters"
    $params = @{}

    foreach($h in $MyInvocation.MyCommand.Parameters.GetEnumerator()) {
        try {
            $key = $h.Key
            $val = Get-Variable -Name $key -ErrorAction Stop | Select-Object -ExpandProperty Value -ErrorAction Stop
            if (([String]::IsNullOrEmpty($val) -and (!$PSBoundParameters.ContainsKey($key)))) {
                Write-Log "A blank value that wasn't supplied by the user for $key."
            }
            Write-Log "$key => '$val'"
            $params[$key] = $val
        } catch {}
    }
    
    ## create PS1 files that execute the start and stop tasks
    Write-Log "Creating start and stop tasks"
    # command to send a stop trace on all nodes
    $rc = "`"$($params.remoteComputer -join '","')`""

    $stopBody = "$rc | foreach { Write-EventLog -ComputerName `$_ -Source PowerShell -LogName `"Windows PowerShell`" -EntryType Information -Message `"Terminate tracing event sent by $(hostname)`.`" -EventId 5709 }"
    $stopBody | Out-File "$Script:ScriptPath\stop-clustertask.ps1" -Encoding ascii -Force
    Write-Log "Created stop task script at: $Script:ScriptPath\stop-clustertask.ps1"
    
    # LEGACY - command to start tracing
    #$startBody = ". `"$Script:ScriptPath\Start-ClusterTrace.ps1`" -tracePath `"$tracePath`" -remoteComputer $rc -traceNic $tn -logName $ln -eventID $eID -eventData `[string`[`]`]$eD -fileSize $fileSize $(if ($GetNetFT.IsPresent) {'-GetNetFT'}) $(if ($GetClusLogs.IsPresent) {'-GetClusLogs'}) -clean -skipValidation"

    ## command to start tracing
    # create a hashtable of parameters
    # this let me add as mant params as needed without adding complexity to the task commands
    $startBody = ""
    $startBody += "`$splat = @{"
    
    $params.Keys | ForEach-Object {
        $key = $_
        $rawVal = $params."$_"

        if ($rawVal -is [array])
        {
            $val = "`@`(`"$($rawVal -join '","')`"`)"
            #$type = "string[]"
        }
        elseif ($rawVal -is [switch])
        {
            if ($key -eq "clean" -or $key -eq "skipValidation")
            {
                $val = "`$true"
            }
            elseif ($key -eq "asTask")
            {
                $val = "`$false"
            }
            else
            {
                $val = "`$$($rawVal.IsPresent)"
            }
            #$type = "switch"
        }
        else
        {
            if ($rawVal -is [string])
            {
                $val = "`"$rawVal`""
            }
            else 
            {
                $val = $rawVal
            }
            
        }

        $startBody += "`n`r`t$key = $val"
    }

    $startBody += "`n`r}`n`r"
    $startBody += ". `"$Script:ScriptPath\Start-ClusterTrace.ps1`" @splat"
    $startBody | Out-File "$Script:ScriptPath\start-clustertask.ps1" -Encoding utf8 -Force
    Write-Log "Created start task script at: $Script:ScriptPath\start-clustertask.ps1"


    # create the Stop-ClusterTrace_MSFT-Nets task
    $taskAction = "powershell.exe"
    $stopTaskArgument = "-NonInteractive -NoProfile -ExecutionPolicy Unrestricted -file `"$Script:ScriptPath\stop-clustertask.ps1`""
    $stopTaskName = 'Stop-ClusterTrace_MSFT-Nets'
    $stopTaskDescription = 'Task to force a stop to the Start-ClusterTrace script.'
    $stopTaskAction = New-ScheduledTaskAction -WorkingDirectory $Script:ScriptPath –Execute $taskAction -Argument $stopTaskArgument
    $stopTaskSettings = New-ScheduledTaskSettingsSet -Compatibility Win8 -MultipleInstances IgnoreNew 
            
    try 
    {
        Register-ScheduledTask -Action $stopTaskAction  -Settings $stopTaskSettings -TaskName $stopTaskName -Description $stopTaskDescription -User 'NT AUTHORITY\SYSTEM' -RunLevel Highest -Force -ErrorAction Stop
    } 
    catch 
    {
        Write-Log "The $stopTaskName scheduled task could not be created:`n$($error[0])" -foreColor Red -tee
        
        #clean up
        Remove-Item "$Script:ScriptPath\start-clustertask.ps1" -Force
        Remove-Item "$Script:ScriptPath\stop-clustertask.ps1" -Force
        exit
    }
    finally
    {
        Write-Log "Created the stop task: $stopTaskName"
    }

    # create Start-ClusterTrace_MSFT-Nets task       
    $taskAction = "powershell.exe"
    $taskArgument = "-NonInteractive -NoProfile -ExecutionPolicy Unrestricted -file `"$Script:ScriptPath\start-clustertask.ps1`""
    $taskName = 'Start-ClusterTrace_MSFT-Nets'
    $taskDescription = 'Task to execute the Start-ClusterTrace script as the SYSTEM user.'
    $taskAction = New-ScheduledTaskAction -WorkingDirectory $Script:ScriptPath –Execute $taskAction -Argument $taskArgument
    $taskTrigger = New-ScheduledTaskTrigger -AtStartup
    $taskSettings = New-ScheduledTaskSettingsSet -Compatibility Win8 -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Days 60)
    
    try {
        $task = Register-ScheduledTask -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings -TaskName $taskName -Description $taskDescription -User 'NT AUTHORITY\SYSTEM' -RunLevel Highest -Force -ErrorAction Stop
    } catch {
        Write-Log "The $taskName scheduled task could not be created:`n$($error[0])" -foreColor Red -tee
        
        #clean up
        Remove-Item "$Script:ScriptPath\start-clustertask.ps1" -Force
        Remove-Item "$Script:ScriptPath\stop-clustertask.ps1" -Force
        exit
    } 
    finally
    {
        Write-Log "Created the stop task: $taskName"
    }

    Write-Log "Starting the start task: $taskName"
    try 
    {
        Start-ScheduledTask -InputObject $task -ErrorAction Stop    
    }
    catch 
    {
        Write-Log "$taskName failed to start: $($error[0].ToString())"
    }
    
    
    # exit the script
    Write-Log "Exiting the script. The main execution is now under $taskName. As long as that task is running the process should be working."
    exit
}

## add the restart event ID 57350
$logName += "Windows PowerShell"
$eventID += 57350
$provider += "PowerShell"

## add the terminate/stop PowerShell event 5709
$logName += "Windows PowerShell"
$eventID += 5709
$provider += "PowerShell"

# create a variable containing the PowerShell stop events for the stop events scriptblock
$poshStop = @()

$poshStop += New-Object psobject @{
    logName = "Windows PowerShell"
    eventID = 57350
    provider = "PowerShell"
}

$poshStop += New-Object psobject @{
    logName = "Windows PowerShell"
    eventID = 5709
    provider = "PowerShell"
}

###################################
### THE BIG SCRIPTBLOCK IS HERE ###
###################################
#region
# setup the scriptblock for the stop events
[scriptblock]$stopHandler = {

# store args in local variables
$remoteComputer = $args[0]
$poshStop = $args[1]
$stopEventID = $args[2]
$taskRestart = $args[3]

# get credentials
$flatCreds = PowerShell -NoProfile -EncodedCommand CgAgACAAIAAgACMAIABzAHQAYQB0AGkAYwAgAHAAYQB0AGgAIAB0AG8AIAB0AGgAZQAgAGMAcgBlAGQAZQBuAHQAaQBhAGwAcwAgAGgAYQBzAGgAIABmAGkAbABlAAoAIAAgACAAIAAkAHAAYQB0AGgAIAA9ACAAIgAkAEUATgBWADoAdwBpAG4AZABpAHIAXAB0AGUAbQBwAFwAcwBjAHIAaQBwAHQALgBoAGEAcwBoACIACgAKACAAIAAgACAACgAgACAAIAAgACMAIABnAGUAbgBlAHIAYQB0AGUAIAB0AGgAZQAgAGsAZQB5ACAAdQBzAGkAbgBnACAAYQAgAGgAYQBzAGgAIABzAG8AIABpAHQAJwBzACAAYQBsAHcAYQB5AHMAIAB0AGgAZQAgAHMAYQBtAGUALAAgAHcAaQB0AGgAbwB1AHQAIAB3AHIAaQB0AGkAbgBnACAAYQBuAHkAdABoAGkAbgBnACAAdABvACAAZgBpAGwAZQAKACAAIAAgACAAJABlAG4AYwAgAD0AIABbAHMAeQBzAHQAZQBtAC4AVABlAHgAdAAuAEUAbgBjAG8AZABpAG4AZwBdADoAOgBBAFMAQwBJAEkACgAgACAAIAAgAFsAcwB0AHIAaQBuAGcAXQAkAHMAdAByAGkAbgBnADEAIAA9ACAAJwA4AE0AcABxAHoAMABqADEATwA0AGQAaABRAEEAMgAzACcAIAAgACAACgAgACAAIAAgACQAaABhAHMAaABlAHIAIAA9ACAAbgBlAHcALQBvAGIAagBlAGMAdAAgAFMAeQBzAHQAZQBtAC4AUwBlAGMAdQByAGkAdAB5AC4AQwByAHkAcAB0AG8AZwByAGEAcABoAHkALgBTAEgAQQAyADUANgBNAGEAbgBhAGcAZQBkAAoAIAAgACAAIAAkAHQAbwBIAGEAcwBoACAAPQAgAFsAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4ARQBuAGMAbwBkAGkAbgBnAF0AOgA6AFUAVABGADgALgBHAGUAdABCAHkAdABlAHMAKAAkAHMAdAByAGkAbgBnADEAKQAKACAAIAAgACAAJABTAGUAYwB1AHIAZQBLAGUAeQAgAD0AIAAkAGgAYQBzAGgAZQByAC4AQwBvAG0AcAB1AHQAZQBIAGEAcwBoACgAJAB0AG8ASABhAHMAaAApAAoACgAgACAAIAAgACMAIABlAHgAdAByAGEAYwB0ACAAdABoAGUAIAB1AHMAZQByACAAYQBuAGQAIABwAGEAcwBzACAAcwBlAGMAdQByAGUAcwB0AHIAaQBuAGcAcwAKACAAIAAgACAAJABmAGkAbABlACAAPQAgAEcAZQB0AC0AQwBvAG4AdABlAG4AdAAgACQAcABhAHQAaAAKAAoAIAAgACAAIABpAGYAIAAoACQAZgBpAGwAZQAuAEMAbwB1AG4AdAAgAC0AZQBxACAAMwApACAAewAKACAAIAAgACAACgAgACAAIAAgACAAIAAgACAAIwAgAGMAbwBuAHYAZQByAHQAIAB0AGgAZQAgAGUAbgBjAHIAeQBwAHQAZQBkACAAcwB0AHIAaQBuAGcAIAB0AG8AIABhACAAcwBlAGMAdQByAGUAcwB0AHIAaQBuAGcACgAgACAAIAAgACAAIAAgACAAJABlAG4AYwBVAHMAZQByACAAPQAgACQAZgBpAGwAZQBbADAAXQAgAHwAIABDAG8AbgB2AGUAcgB0AFQAbwAtAFMAZQBjAHUAcgBlAFMAdAByAGkAbgBnACAALQBrAGUAeQAgACQAUwBlAGMAdQByAGUASwBlAHkACgAgACAAIAAgACAAIAAgACAAJABlAG4AYwBEAG8AbQBhAGkAbgAgAD0AIAAkAGYAaQBsAGUAWwAxAF0AIAB8ACAAQwBvAG4AdgBlAHIAdABUAG8ALQBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwAgAC0AawBlAHkAIAAkAFMAZQBjAHUAcgBlAEsAZQB5AAoAIAAgACAAIAAgACAAIAAgACQAZQBuAGMAUABhAHMAcwAgAD0AIAAkAGYAaQBsAGUAWwAyAF0AIAB8ACAAQwBvAG4AdgBlAHIAdABUAG8ALQBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwAgAC0AawBlAHkAIAAkAFMAZQBjAHUAcgBlAEsAZQB5AAoACgAgACAAIAAgACAAIAAgACAAIwAgAGMAbwBuAHYAZQByAHQAIAB1AHMAZQByAG4AYQBtAGUAIAB0AG8AIABwAGwAYQBpAG4AIAB0AGUAeAB0AAoAIAAgACAAIAAgACAAIAAgACQAQgBTAFQAUgAgAD0AIABbAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAUwBlAHIAdgBpAGMAZQBzAC4ATQBhAHIAcwBoAGEAbABdADoAOgBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwBUAG8AQgBTAFQAUgAoACQAZQBuAGMAVQBzAGUAcgApAAoAIAAgACAAIAAgACAAIAAgACQAdQBzAGUAcgAgAD0AIABbAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAUwBlAHIAdgBpAGMAZQBzAC4ATQBhAHIAcwBoAGEAbABdADoAOgBQAHQAcgBUAG8AUwB0AHIAaQBuAGcAQQB1AHQAbwAoACQAQgBTAFQAUgApAAoAIAAgACAAIAAKACAAIAAgACAAIAAgACAAIAAjACAAYwBvAG4AdgBlAHIAdAAgAGQAbwBtAGEAaQBuACAAdABvACAAcABsAGEAaQBuACAAdABlAHgAdAAKACAAIAAgACAAIAAgACAAIAAkAEIAUwBUAFIAIAA9ACAAWwBTAHkAcwB0AGUAbQAuAFIAdQBuAHQAaQBtAGUALgBJAG4AdABlAHIAbwBwAFMAZQByAHYAaQBjAGUAcwAuAE0AYQByAHMAaABhAGwAXQA6ADoAUwBlAGMAdQByAGUAUwB0AHIAaQBuAGcAVABvAEIAUwBUAFIAKAAkAGUAbgBjAEQAbwBtAGEAaQBuACkACgAgACAAIAAgACAAIAAgACAAJABkAG8AbQBhAGkAbgAgAD0AIABbAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAUwBlAHIAdgBpAGMAZQBzAC4ATQBhAHIAcwBoAGEAbABdADoAOgBQAHQAcgBUAG8AUwB0AHIAaQBuAGcAQQB1AHQAbwAoACQAQgBTAFQAUgApAAoACgAgACAAIAAgACAAIAAgACAAIwAkAGMAcgBlAGQAcwAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAALQBUAHkAcABlAE4AYQBtAGUAIABTAHkAcwB0AGUAbQAuAE0AYQBuAGEAZwBlAG0AZQBuAHQALgBBAHUAdABvAG0AYQB0AGkAbwBuAC4AUABTAEMAcgBlAGQAZQBuAHQAaQBhAGwAIAAtAEEAcgBnAHUAbQBlAG4AdABMAGkAcwB0ACAAJAAoACIAJABEAG8AbQBhAGkAbgBcACQAVQBzAGUAcgAiACkALAAgACQAZQBuAGMAUABhAHMAcwAKACAAIAAgACAAfQAgAGUAbABzAGUAIAB7AAoAIAAgACAAIAAgACAAIAAgACMAIABjAG8AbgB2AGUAcgB0ACAAdABoAGUAIABlAG4AYwByAHkAcAB0AGUAZAAgAHMAdAByAGkAbgBnACAAdABvACAAYQAgAHMAZQBjAHUAcgBlAHMAdAByAGkAbgBnAAoAIAAgACAAIAAgACAAIAAgACQAZQBuAGMAVQBzAGUAcgAgAD0AIAAkAGYAaQBsAGUAWwAwAF0AIAB8ACAAQwBvAG4AdgBlAHIAdABUAG8ALQBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwAgAC0AawBlAHkAIAAkAFMAZQBjAHUAcgBlAEsAZQB5AAoAIAAgACAAIAAgACAAIAAgACQAZQBuAGMAUABhAHMAcwAgAD0AIAAkAGYAaQBsAGUAWwAxAF0AIAB8ACAAQwBvAG4AdgBlAHIAdABUAG8ALQBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwAgAC0AawBlAHkAIAAkAFMAZQBjAHUAcgBlAEsAZQB5AAoACgAgACAAIAAgACAAIAAgACAAIwAgAGMAbwBuAHYAZQByAHQAIAB1AHMAZQByAG4AYQBtAGUAIAB0AG8AIABwAGwAYQBpAG4AIAB0AGUAeAB0AAoAIAAgACAAIAAgACAAIAAgACQAQgBTAFQAUgAgAD0AIABbAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAUwBlAHIAdgBpAGMAZQBzAC4ATQBhAHIAcwBoAGEAbABdADoAOgBTAGUAYwB1AHIAZQBTAHQAcgBpAG4AZwBUAG8AQgBTAFQAUgAoACQAZQBuAGMAVQBzAGUAcgApAAoAIAAgACAAIAAgACAAIAAgACQAdQBzAGUAcgAgAD0AIABbAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAUwBlAHIAdgBpAGMAZQBzAC4ATQBhAHIAcwBoAGEAbABdADoAOgBQAHQAcgBUAG8AUwB0AHIAaQBuAGcAQQB1AHQAbwAoACQAQgBTAFQAUgApAAoACgAgACAAIAAgACAAIAAgACAAIwAkAGMAcgBlAGQAcwAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAALQBUAHkAcABlAE4AYQBtAGUAIABTAHkAcwB0AGUAbQAuAE0AYQBuAGEAZwBlAG0AZQBuAHQALgBBAHUAdABvAG0AYQB0AGkAbwBuAC4AUABTAEMAcgBlAGQAZQBuAHQAaQBhAGwAIAAtAEEAcgBnAHUAbQBlAG4AdABMAGkAcwB0ACAAJABVAHMAZQByACwAIAAkAGUAbgBjAFAAYQBzAHMACgAgACAAIAAgAH0ACgAgACAAIAAgAHIAZQB0AHUAcgBuACAAIgAkAHUAcwBlAHIAIgAsACIAJABkAG8AbQBhAGkAbgAiACwAIgAkACgAJABlAG4AYwBQAGEAcwBzACAAfAAgAEMAbwBuAHYAZQByAHQARgByAG8AbQAtAFMAZQBjAHUAcgBlAFMAdAByAGkAbgBnACkAIgAKACAAIAAgACAAIwByAGUAdAB1AHIAbgAgACQAYwByAGUAZABzAAoACgA=

if ($flatCreds[1] -ne "") {
    $creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$($flatCreds[1])\$($flatCreds[0])", $($flatCreds[2] | ConvertTo-SecureString)
} else {
    $creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$($flatCreds[0])", $($flatCreds[2] | ConvertTo-SecureString)
}

Remove-Variable flatCreds

# send stop events to the other nodes
function Send-TraceStop
{
    param(
        [string[]]$remoteComputer,
        [int]$stopEventID = 57350,
        [PSCredential]$creds
    )

    if ($stopEventID -eq 57350)
    {
        $txt = "Stop tracing event sent by $env:COMPUTERNAME`."
    } else 
    {
        $txt = "Terminate tracing event sent by $env:COMPUTERNAME`."
    }
    
    [scriptblock]$tmpSB = { Write-EventLog -Source PowerShell -LogName "Windows PowerShell" -EntryType Information -Message $args[0] -EventId $args[1] }

    $remoteComputer | ForEach-Object { 
        Invoke-Command -Computername $_ -Credential $creds -Scriptblock $tmpSB -ArgumentList $txt,$stopEventID
    }
}


# remove the local host from remoteComputer
[string[]]$remoteComputer = $remoteComputer | Where-Object {$_ -ne "$(hostname)"}

# send initial stop messages
Send-TraceStop -remoteComputer $remoteComputer -stopEventID $stopEventID -creds $creds


# used to keep queries to the event logs down to a manageable time period
$time = (Get-Date).AddMinutes(-2)
#$timeResetDelay = 2

# stops the job after 3 minutes regardless of whether all stop events have been returned.
$masterStop = (Get-Date).AddMinutes(3)

# set a stopwatch to update $time every 3 minutes
$sw = New-Object System.Diagnostics.StopWatch
$sw.Start()

# loop control variables
$loopCount = 1


$stops = @()
$stop = $false
do {
    # pause the loop to control loop speed/reduce CPU overhead
    Start-Sleep -m 500
    
    # pull stop events
    #[array]$events = Get-WinEvent -FilterHashtable @{logname="$($poshStop.logName)"; id="$($poshStop.eventID)"; StartTime="$($time)"} -EA SilentlyContinue
    # search for matches using the appropriate filter
    [hashtable]$eventFilter = @{LogName=$($poshStop.logName); ProviderName=$($poshStop.provider); ID=$($poshStop.eventID); StartTime=$time}
    $events = Get-WinEvent -FilterHashtable $eventFilter -EA SilentlyContinue

    # when events are found, run checks to see if events from all remoteComputer's have been returned
    if ($events) 
    {
        foreach ($event in $events) {
            # parse events for sending node
            $temp = ($event.properties.value -split ' ')[-1].trimend('.')
            # if this is a new hostname store it in the master list
            if ($stops -notcontains $temp) {
                $stops += $temp
            }
        } #end foreach

        # compare the returns to the remoteComputer list
        $compare = Compare-Object $stops $remoteComputer

        # stop the loop if they match
        if (!$compare) 
        {
            $stop = $true
        }
    } #end if ($events)

    # restart the stopwatch and update time if stopwatch greater than timeResetDelay minutes
    if (!$stop) { 
        # resend stop messages
        Send-TraceStop -remoteComputer $remoteComputer -stopEventID $stopEventID -creds $creds
    }

    $loopCount++
    
} until ($stop -or ((get-date) -gt $masterStop))


# remove the credentials if the task isn't restarting
if (-NOT $taskRestart)
{
    PowerShell -NoProfile -EncodedCommand CgAgACAAIAAgACMAIABzAHQAYQB0AGkAYwAgAHAAYQB0AGgAIAB0AG8AIAB0AGgAZQAgAGMAcgBlAGQAZQBuAHQAaQBhAGwAcwAgAGgAYQBzAGgAIABmAGkAbABlAAoAIAAgACAAIAAkAHAAYQB0AGgAIAA9ACAAIgAkAEUATgBWADoAdwBpAG4AZABpAHIAXAB0AGUAbQBwAFwAcwBjAHIAaQBwAHQALgBoAGEAcwBoACIACgAKACAAIAAgACAAUgBlAG0AbwB2AGUALQBJAHQAZQBtACAAJABwAGEAdABoACAALQBGAG8AcgBjAGUAIAAtAEUAQQAgAFMAaQBsAGUAbgB0AGwAeQBDAG8AbgB0AGkAbgB1AGUACgA=
}
}
#endregion BIG SCRIPTBLOCK - stopHandler


Write-Log "Beginning the trace." -foreColor Green -tee

switch -Regex ($Script:osName) {
        "^2012$" 
        { 
            Write-Log -f Yellow "If you terminate the script with Ctrl+C you need to run `"netsh trace stop`" on all nodes running this trace script!`n" -tee
        }
        "2012R2|10" 
        {
            Write-Log -f Yellow "If you terminate the script with Ctrl+C you need to run the following commands in PowerShell to stop tracing:`nGet-NetEventSession | Stop-NetEventSession`nGet-NetEventSession | Remove-NetEventSession`n" -tee
        }
}


# create a text file with some details about the trace
if (!(test-path "$dataPath\trace_stop.txt")) {New-Item "$dataPath\trace_stop.txt" -ItemType File -Force | Out-Null}
# get starting ipconfig
"Start ipconfig:`r`n" | Out-File "$dataPath\trace_stop.txt" -Force
ipconfig /all | Out-File "$dataPath\trace_stop.txt" -Append

## Start tracing

Write-Log "Starting packet capture."
# generate a filename
$filename = "$(hostname)`_$(get-date -format "yyyyMMddHHmmss")`.etl"
$traceFile = "$dataPath\$filename"

# some generic settings for the trace
$name = "cluster_trace"
[string]$CaptureMode = "SaveToFile"
[string]$captureType = "Physical"

[int]$maxSize = 1024        
[int]$TraceBufferSize = 1024
[byte]$MaxNumberOfBuffers = [Byte]::MaxValue
[byte]$capLevel = 0x4
[int]$truncBytes = 1500
$PromiscuousMode = $false
$scenarios = $null

## start the ETW/packet capture ##
$cap = Start-Trace -name $name -CaptureMode $CaptureMode -traceFile $traceFile -maxSize $maxSize -TraceBufferSize $TraceBufferSize -MaxNumberOfBuffers $MaxNumberOfBuffers `
                         -udpOnly $udpOnly -capLevel $capLevel -captureType $captureType -truncBytes $truncBytes `
                         -traceNic $traceNic -PromiscuousMode $PromiscuousMode `
                         -scenarios $scenarios -PROVIDER_LIST $PROVIDER_LIST `
                         -noCapture $noCapture

# exit if the capture fails to start, i.e. null returned
if (!$cap)
{
    Write-Log "ERROR! Failed to start the trace."
    exit
}

# start logs
if ($EVENT_LOG_LIST) {
    Start-Log $EVENT_LOG_LIST
    $Script:ALL_LOGS = Get-WinEvent -ListLog *
}

# start NetFt trace
if ($GetNetFT) 
{
    Write-Log "Starting NetFT trace."
    Start-NetFtTrace -tracePath $dataPath
}

# start Perfmon logs
if ($GetPerfmon) {
    Write-Log "Starting perfmon."
    Start-GetPerfmon -tracePath $dataPath
}

## start event watching ##

# used to keep queries to the event logs down to a manageable time period
$time = Get-Date

# set a stopwatch to update $time every 3 minutes
$sw = New-Object System.Diagnostics.StopWatch
$sw.Start()

Write-Log "Waiting for a stop event."
# wait for the stop event
do {
    Start-Sleep -m $loopSensitivity
    
    # search for matches using the appropriate filter
    [hashtable]$eventFilter = @{LogName=$logName; ProviderName=$provider; ID=$eventID; StartTime=$time}

    [array]$stop = Get-WinEvent -FilterHashtable $eventFilter -EA SilentlyContinue

    # restart the stopwatch and update time if stopwatch greater than 3 minutes
    if (!$stop -and $sw.Elapsed.TotalMinutes -gt $timeResetDelay) { 
        # subtract a minute from the time or you run the risk of missing the stop event.
        $time = (Get-Date).AddMinutes(-1)

        # restart the timer (do not use Restart(), as older versions of .NET do not support it).
        $sw.Stop()
        $sw.Reset()
        $sw.Start()
    }
} until ($stop)


# send end event to remote computer(s)
Write-Log "Stop event received. Sending redundant stop events to: $($remoteComputer)" -foreColor Green

# start the job to stop the traces. runs in background to prevent extra delays in stopping the traces.
$sendTerminate = $stop | Where-Object {$_.ID -eq 5709}
Write-Log "Starting stop trace job."
if ($sendTerminate)
{
    Start-Job -Name "Stopping Traces" -ScriptBlock $stopHandler -ArgumentList $remoteComputer, $poshStop, 5709, $false
} 
else 
{
    Start-Job -Name "Stopping Traces" -ScriptBlock $stopHandler -ArgumentList $remoteComputer, $poshStop, 57350, $true | Out-Null
}

# stop NetFt
if ($GetNetFT) {
    Write-Log "Stopping NetFT."
    Stop-NetFtTrace
}

# stop Perfmon logs
if ($GetPerfmon) {
    Write-Log "Stopping perfmon."
    Stop-GetPerfmon
}

# stop the trace
#netsh trace stop

# stop the trace
Write-Log "Stopping packet capture."
Stop-Trace $cap


Write-Log "A stop event was found:`n$($stop | Select-Object Id,LogName,ProviderName,MachineName,TimeCreated,LevelDisplayName,OpcodeDisplayName,TaskDisplayName -ExpandProperty Properties | Out-String)" -foreColor Yellow -tee

# add stop event
"`r`n`r`nStop event:`r`n`r`n" | Out-File "$dataPath\trace_stop.txt" -Append
$stop | Select-Object Id,LogName,ProviderName,MachineName,TimeCreated,LevelDisplayName,OpcodeDisplayName,TaskDisplayName -ExpandProperty Properties | Format-List * | Out-String | Out-File "$dataPath\trace_stop.txt" -Append

# add ipconfig information
"`r`n`r`nEnd ipconfig:`r`n" | Out-File "$dataPath\trace_stop.txt" -Append
ipconfig /all | Out-File "$dataPath\trace_stop.txt" -Append


# get cluster logs
if ($GetClusLogs) 
{
    Write-Log "Collecting cluster logs."

    # make the cluster log folder
    $clusLogDir = "$dataPath\clusLogs"
    if (!(Test-Path "$clusLogDir")) {
        New-Folder "$clusLogDir"
    }
    
    # do te work
    Get-ClusterLog -Node $env:COMPUTERNAME  -Destination $clusLogDir
    #Get-ChildItem "$clusLogDir" | Move-Item -Destination $dataPath
    Write-Log "Cluster logs collected."
}


# stop event logs
if ($Script:Started_Logs) {
    Write-Log "Collecting event logs."
    Stop-Log $Script:Started_Logs
}

# copy the event logs
foreach ($log in $EVENT_LOG_LIST) {
    Copy-Log -logName $log -destination "$dataPath" | Out-Null
}


# run post capture commands
Start-Command $POST_COMMANDS $dataPath

<# 
    There are two conditions where the clean code is run.

    1. -clean and -taskRestart are set, and a terminate command has been received (Windows PowerShell event ID 5709).
    2. -clean is set, but -taskRestart was not set.

    Any other combination of conditions assumes that the tracing task needs to be restarted.

#>
if (($clean -and $taskRestart -and $sendTerminate) -or ($clean -and !$taskRestart)) {
    Write-Log "Cleaning up." -foreColor Green

    # name of the start and stop tasks
    $stopTaskName = 'Stop-ClusterTrace_MSFT-Nets'
    $taskName = 'Start-ClusterTrace_MSFT-Nets'

    # setup start task delete as a job that sleeps for 5 seconds before removing task to give the task time to end before deleting
    Write-Log "Unregistering the scheduled tasks."
    Unregister-ScheduledTask -TaskName $stopTaskName -Confirm:$false        
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    

    Write-Log "Deleting the task files."
    Remove-Item "$Script:ScriptPath\start-clustertask.ps1" -Force
    Remove-Item "$Script:ScriptPath\stop-clustertask.ps1" -Force
    $isRestart = Get-Item "$Script:ScriptPath\Restart-ClusterTask.ps1" -ErrorAction SilentlyContinue
    if ($isRestart)
    {
        Remove-Item "$Script:ScriptPath\Restart-clustertask.ps1" -Force
    }
}


# stop and remove any running jobs, wait 3 minutes if there is a job still running
Write-Log "Waiting for jobs to complete."

$sw = New-Object System.Diagnostics.StopWatch
$sw.Start()

do {
    Start-Sleep 10
    $runningJobs = Get-Job | Where-Object {$_.State -ne "Completed"}
} until (!$runningJobs -or $sw.Elapsed.TotalMinutes -ge 3.5)

Write-Log "Cleaning up jobs."
Get-Job | Stop-Job
Get-Job | Remove-Job


# restart the script when taskRestart set
if ($taskRestart -and !$sendTerminate) {
    
    Write-Log "Restarting the collection."
    #######################
    ### PETE AND REPEAT ###
    #######################

    # the scriptblock creates the restart script
    [scriptblock]$peteAndRepeat = {
# the name of the task that needs to be run
$taskName = "Start-ClusterTrace_MSFT-Nets"

# OS version
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
[int]$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
[int]$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor

# loop until the task is no longer running
do
{
        $running = (Get-ScheduledTask -TaskName $taskName).State
} while ($running -eq "Running")

"Task stopped running" | Out-File "C:\ClusterTrace_MSFT-Nets-restart.txt" -Force

# sleep for a second to let things settle
Start-Sleep -Seconds 1

# set a stopwatch to update $time every 3 minutes
$sw = New-Object System.Diagnostics.StopWatch
$sw.Start()

# how long to retry starting the task
$retryTimer = 2

do {
    # start the task
    $task = Get-ScheduledTask -TaskName $taskName
    Start-ScheduledTask -InputObject $task
    
    "Task started?" | Out-File "C:\ClusterTrace_MSFT-Nets-restart.txt" -Append

    # wait 10 seconds for tracing task to start
    Start-Sleep -Seconds 10

    $running = (Get-ScheduledTask -TaskName $taskName).State

    "Task status: $running" | Out-File "C:\ClusterTrace_MSFT-Nets-restart.txt" -Append
} until ($sw.Elapsed.TotalMinutes -ge $retryTimer -or $running -eq "Running")
} #end scriptblock


    Write-Log "Building the restart job."

    # create the restart script
    $peteAndRepeat | Out-File "$Script:ScriptPath\restart-clustertask.ps1" -Encoding utf8 -Force | Out-Null

    # start a new PowerShell process that will start the task when it stops
    $processName = "powershell.exe"
    $processArgument = "-NonInteractive -NoProfile -ExecutionPolicy Unrestricted -file `"$Script:ScriptPath\restart-clustertask.ps1`""

    Write-Log "Starting the restart task."
    Start-Process -FilePath $processName -ArgumentList $processArgument -WorkingDirectory $Script:ScriptPath
}


## Compress the data

# cab file path and name
$cabFile = "$env:COMPUTERNAME`_traceData`_$startTS"

Write-Log "Compressing $dataPath." -tee
# this is a duplicate so it gets in the log before compression
Write-Log "Please upload $compressPath to Microsoft."
$compressPath = Compress-Directory -dir "$dataPath" -cabName $cabFile -cabPath "$tracePath"

# prompt customer with zip file path and name
Write-Log "Please upload $compressPath to Microsoft." -f Green -tee

<#
# stop the task just before exit
$running = (Get-ScheduledTask -TaskName $taskName).State
if ($running -eq "Running")
{
    Stop-ScheduledTask -TaskName $taskName
}
#>