# Queries EDP WNFs to get current configuration state.
#
param($scriptOutputPath, $scriptmode)

$logpath = $scriptOutputPath + "\\" + $scriptmode + "EdpState.log"
Add-Content -Path $logpath -Value ($scriptmode + ": Log EDP config info")

# WNF (and other) p/invoke types.
Add-Type -Path ($PSScriptRoot + "\\edputil.cs")

$edpEnforcementLevelCachedWnf = new-object WnfStateName([uint32]"0xa3bd5c75", [uint32]"0x13920028")

$change = 0;
$buffer = new-object byte[] 4
$buffersize = $buffer.length
$typeid = [IntPtr]::Zero
$scope = [IntPtr]::Zero

$return = [WnfUtil]::QueryWnfStateData([ref] $edpEnforcementLevelCachedWnf, $typeid, $scope, [ref] $change, $buffer, [ref] $buffersize)
Add-Content -Path $logpath -Value "WNF_ENTR_EDPENFORCEMENTLEVEL_CACHED_POLICY_VALUE_CHANGED:"
Add-Content -Path $logpath -Value ("change stamp: " + $change)
Add-Content -Path $logpath -Value ("EDPEnforcementLevel value: " + $buffer[0].ToString())

$typeid = [IntPtr]::Zero
$scope = [IntPtr]::Zero
$change = 0;
$protectedDomainNamesCachedWnf = new-object WnfStateName([uint32]"0xa3bd6475", [uint32]"0x13920028")

$bufferForEpdns = new-object byte[] 1024
$bufferSizeForEpds = $bufferForEpdns.length

$return = [WnfUtil]::QueryWnfStateData([ref] $protectedDomainNamesCachedWnf, $typeid, $scope, [ref] $change, $bufferForEpdns, [ref] $bufferSizeForEpds)
Add-Content -Path $logpath -Value ("")
Add-Content -Path $logpath -Value "WNF_ENTR_PROTECTEDDOMAINNAMES_CACHED_POLICY_VALUE_CHANGED:"
Add-Content -Path $logpath -Value ("change stamp: " + $change)
Add-Content -Path $logpath -Value ("EnterpriseIds value: " + [System.Text.Encoding]::Unicode.GetString($bufferForEpdns))

# Other examples...
#[WnfUtil]::DmWnfPublish($wnf, $buffer, $buffer.Length)
#[WnfUtil]::PublishWnfStateData($wnf, [IntPtr]::Zero, $buffer, $buffer.length, [IntPtr]::Zero)


