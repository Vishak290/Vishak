﻿
function Get-OfficeC2RBuildNumber {

    try{
        $ClientVersionToReportKey = Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration -ErrorAction Stop 
        return [string]$ClientVersionToReportKey.ClientVersionToReport
    } catch {
        if ($_.CategoryInfo.Reason = "ItemNotFoundException" )
        {
            Write-Host "C2R Office Installation not found."
            return "C2RNotFoundError"
        } else {
            Return $_
        }

    }


}


Get-OfficeC2RBuildNumber

