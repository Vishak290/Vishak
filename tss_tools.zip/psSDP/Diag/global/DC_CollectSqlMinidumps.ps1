
# This script has dependencies on utils_CTS and utils_DSD
#
param ( [Object[]] $instances ) 

# 2019-03-17 WalterE added Trap #_#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

New-Variable LOGFILE_PATH      -Scope "Global" 

#
# Function : WriteTo-LogFile
# ---------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function should is used to log progress and error messages to the ErrorloLogCollectorResults.log 
#			file and the test harness executes
# 
# Arguments:
#			String to write to file
# 
# Owner:
#			DanSha 
#
function WriteTo-LogFile($StringToWrite)
{
	$Error.Clear()           
    trap 
    {
    	"[WriteTo-LogFile] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error 
	}

	"[{0:yyyy-MM-dd HH:mm:ss.fff}] : {1}" -f (Get-Date), $StringToWrite |  Out-File -FilePath $global:LOGFILE_PATH -Append
}

#
# Function : Write-DumpInventory
# ------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
#		    Writes an inventory of all dump files found for target instance
# 
# Arguments:
#			String to write to file
# 
# Owner:
#			DanSha 
#   
function Write-DumpInventory([string]$InstanceName, [string]$DumpDir)
{
    $Error.Clear()           
    trap 
    {
    	"[Write-DumpInventory] : [EROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error
    }
   
    if ($null -ne $InstanceName)
    {
        if ($null -ne $DumpDir)
        {
            # This collector can be configured to collect a subset of the minidumps on a given machine.  
            # As such, for debugging purposes the collector writes a dump inventory that's collected with the dump files  
            $DumpInventoryFile = "{0}_{1}_DumpInventory.log" -f $env:ComputerName, $InstanceName
            New-Item -ItemType file -Name $DumpInventoryFile -Path $PWD.Path -Force | Out-Null
            $global:LOGFILE_PATH = Join-Path -Path $PWD.Path -ChildPath $DumpInventoryFile 
            
            # Is path passed to function in $DumpDir valid?
            if ($true -eq (Test-Path -Path $DumpDir -PathType "Container"))
            {
                # Collect (up to) 10 most recent minidump files for this instance
                $Dumpfiles = get-childitem -Path (Join-Path $Dumpdir "*") -Include "*.mdmp" | sort-object -Property Length -Descending
                
                if ($true -eq (Test-Path -Path $global:LOGFILE_PATH -PathType "Leaf"))
                {
                    WriteTo-LogFile ("Dump inventory for instance: {0}" -f $InstanceName)
                    WriteTo-LogFile ("Dump directory: {0}" -f $DumpDir)
                    
                    if ($null -ne $Dumpfiles) 
                    {
                        if (0 -lt $Dumpfiles.Count) 
                        {
                            WriteTo-LogFile ("Total number of dumps discovered is: {0}" -f $Dumpfiles.Count)
                            
                            foreach($DumpFile in $Dumpfiles)
                            {
                                WriteTo-LogFile ("{0} Creation Time: {1} Size: {2}" -f $DumpFile.Name, $DumpFile.CreationTime, $DumpFile.Length)
                            }
                        }
                    }
                    else
                    {
                        WriteTo-LogFile "No minidumps found ..." 
                    }
            		# Now collect the file so that it will be included in CAB that's uploaded
                	CollectFiles -FilesToCollect $global:LOGFILE_PATH -SectionDescription ("SQL Server minidumps and related files for instance {0}" -f $InstanceName)
                }
            }
            else
            {
                "[Write-DumpInventory] : [ERROR] Invalid path [{0}] passed by caller" -f $DumpDir | WriteTo-StdOut        
            }
            
        } # if ($null -eq $DumpDir)
        else
        {
             '[Write-DumpInventory] : [ERROR] Required parameter -DumpDir was not specified' | WriteTo-StdOut        
        }
        
    } # if ($null -eq $InstanceName)
    else
    {
        '[Write-DumpInventory] : [ERROR] Required parameter -InstanceName was not specified' | WriteTo-StdOut        
    }
}


# This function works with and returns the dump directory as a string so not susceptible to issues caused by
# cluster drive being offline to the node the collector is run against
function Get-DumpDirectory ([string] $SqlInstance)
{
    $Error.Clear()           
	trap 
	{
		"[Get-DumpDirectory] : [ERROR] Trapped exception ..." | WriteTo-Stdout
		Report-Error
	}
    
    if ($null -ne $SqlInstance)
    {
    	$InstanceKey = Get-SqlInstanceRootKey -SqlInstanceName $SqlInstance
        
        if ($null -ne $InstanceKey)
        {
        								
        	if ($true -eq (Test-Path -Path (Join-Path -Path $InstanceKey -ChildPath '\CPE')))
        	{				
        		$CpeRegKey = Join-Path -Path $InstanceKey -ChildPath '\CPE'
        		
                # Test to be sure CpeRegKey is valid
                if ($true -eq (Test-Path -Path $CpeRegKey))
                {
                    # Get the MSSQLServer\Parameters Key
            		$SqlDumpDir = (Get-ItemProperty -Path $CpeRegKey ).ErrorDumpDir
                    
                    if ($true -ne $?)
                    {
                        "[Get-DumpDirectory] : [ERROR] Failed to retrieve ErrorDumpDir registry value from key: [{0}]" -f $CpeRegKey | WriteTo-StdOut
                        Report-Error
                    }
                }  
                else
                {
                    "[Get-DumpDirectory] : [ERROR] Cpe registry key: [{0}] is invalid or does not exist" -f $CpeRegKey | WriteTo-StdOut
                    Report-Error
                }              
                
        	}
        	else
        	{
        		# Report that we could not locate the SQL Server dump directory
        		"[Get-DumpDirectory] : [ERROR] Unable to locate dump directory for SQL Instance: [{0}]" -f $SqlInstance | WriteTo-StdOut
        		"[Get-DumpDirectory] : [ERROR] Registry key: [{0}] is invalid" -f ($InstanceKey + "\CPE") | WriteTo-StdOut
        	}
            
        } # if ($null -ne $InstanceKey)
        else
        {
            '[Get-DumpDirectory] : [ERROR] Get-SqlInstanceRootKey returned a null value' | WriteTo-StdOut
        }
    } 
    else
    {
        '[Get-DumpDirectory] : [ERROR] Required parameter -SqlInstance was not specified' | WriteTo-StdOut
    }
    
	return $SqlDumpDir
}

#
# Function : Collect-SqlServerMinidumps
# --------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function directly. Instead, call the top-level script and pass args
#			indicating which instances to collect dumps for  
#
# Description:
# 			This function enumerates the minidump files for a given SQL Server installation and 
# 
# Arguments:
#			String to write to file
# 
# Owner:
#			DanSha 
#
function Collect-SqlServerMinidumps ([string]$InstanceToCollect, [bool]$IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	"[Collect-SqlServerMinidumps] : [ERROR] Trapped error ..." | WriteTo-StdOut
    	Report-Error 
    }
	
    If ($null -ne $InstanceToCollect)
    {
        if ($null -ne $IsClustered)
        {
            $DumpDir = Get-DumpDirectory -SqlInstance $InstanceToCollect

        	if ($null -ne $DumpDir)
            {
                # Make sure the dump directory path is valid. 
                # When SQL Server is clustered, the instance could be online to another cluster node
                # If so, the drive where the dumps are stored may be offline from the node where the collector is running
                #
                if (Test-Path -Path $DumpDir -PathType "Container")
                {
                    $DumpCount = get-childitem -Path (Join-Path -Path $Dumpdir -ChildPath "*") -Include "*.mdmp" | Get-Count
                    
                    # Create the dump inventory report ... even if there are no dumps present ... report will indicate this
                    Write-DumpInventory -InstanceName $InstanceToCollect -DumpDir $DumpDir
                    
                    $FileFilters = @('*.mdmp')
                    
                    # First pass, enumerate the files but to not copy
				    $DumpFiles = @()
				    $DumpFiles = Copy-FileSql -SourcePath $DumpDir `
                         -FileFilters $FileFilters `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_MINIDUMPS `
                         -InstanceName $InstanceToCollect `
						 -EnumerateOnly
                                            
                    #Since forcing an array to be created with above syntax need to check the length to see if there are any entries in array
                    if (($null -ne $DumpFiles) -and (0 -ne $Dumpfiles.Length))
                    {
                        # Need to go get the SQLDUMP*.log and SQLDUMP*.txt files associated with the dumps we just collected
                        foreach ($file in $dumpfiles)
                        {
                           $LogFileFullPath = $file.Replace("mdmp", "log")
                           # Add the .log file to the list of filefilters to enumerate.  No need to test-path as the enumerate/copy routine does this
                           $FileFilters += split-path -Leaf -Path $LogFileFullPath
                           
                           $TxtFileFullPath = $file.Replace("mdmp", "txt")
                           $FileFilters += split-path -Leaf -Path $TxtFileFullPath
                        } 
                        
                        # Add SQLDUMPER_ERRORLOG
                        $FileFilters += "SQLDUMPER_ERRORLOG.log" 
                       
                        # Add exception.log if present
                        $FileFilters += "exception.log" 
                        
                        $MiniDumpArchiveName = "{0}_{1}_{2}_SqlMiniDumps.zip" -f $env:ComputerName, $InstanceToCollect, (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect)
                    
                        # Re-enumerate, this time copy and compress since we should have all files we want.  FilePolicy is applied "by filter" so no need
                        # to adjust it to account for additional files for this subsequent call
                        $DumpFiles = @()
				        $DumpFiles = Copy-FileSql -SourcePath $DumpDir `
                         -FileFilters $FileFilters `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_MINIDUMPS `
                         -InstanceName $InstanceToCollect `
                         -SectionDescription ("SQL Server minidumps and related files for instance {0}" -f $InstanceToCollect) `
                         -ZipArchiveName $MiniDumpArchiveName `
                         -CompressCollectedFiles
                         #-RenameCollectedFiles
                         
         
					} # if (($null -ne $DumpFiles) -and (0 -ne $Dumpfiles.Length))
                    else
                    {
                        "[Collect-SqlServerMinidumps] : [INFO] No minidumps found for instance: [{0}]" -f $InstanceToCollect | WriteTo-StdOut
                    }  
                }
                # Test-path failed for $DumpDir ... could be because the cluster resource where the dumpfiles are stored is offline to this cluster node
                else 
            	{
                    if ($true -eq (Check-IsSqlDiskResourceOnline $InstanceToCollect $DumpDir))
                    {
                        "[Check-IsSqlDiskResourceOffline] : [ERROR] Path to minidumps: [{0}] for instance: {1} is invalid" -f $DumpDir, $InstanceToCollect | WriteTo-StdOut
                    }
            	}
                
            } #if ($null -ne $DumpDir)
            else
            {
                '[Collect-SqlServerMinidumps] : [ERROR} Get-Dumpdirectory returned a null dump directory path for instance: [{0}]' -f $InstanceToCollect  | WriteTo-StdOut
            }
            
        } # if ($null -ne $IsClustered)
        else
        {
            '[Collect-SqlServerMinidumps] : [ERROR} Required parameter -IsClustered was not specified' | WriteTo-StdOut
        }
        
    } # If ($null -ne $InstanceToCollect)
    else
    {
        '[Collect-SqlServerMinidumps] : [ERROR} Required parameter -InstanceToCollect was not specified' | WriteTo-StdOut
    }
} 

#
# Script entry point
#
#region: MAIN ::::: 
$Error.Clear()           
trap 
{
	"[DC-CollectSqlSqlMinidumps] : [ERROR] Trapped error ..." | WriteTo-StdOut
	Report-Error
}
	
Import-LocalizedData -BindingVariable minidumpCollectorStrings

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance parameter is null, collect minidumps for all instances installed on machine
	#
	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
    
    if ($null -ne $instances)
    {
    
        foreach ($instance in $instances)
        {
			"[DC-CollectSqlSqlMinidumps] : Attempting to collect minidumps for SQL instance: [{0}]" -f $instance.InstanceName | WriteTo-StdOut
            Write-DiagProgress -Activity $minidumpCollectorStrings.ID_SQL_CollectSqlMinidumps -Status ($minidumpCollectorStrings.ID_SQL_CollectSqlMinidumpsDesc + ": " + $instance.InstanceName)
			
            # DEFAULT instance name is MSSQLSERVER in registry and filesystem.  Translate it here before doing any work
            if ('DEFAULT' -eq $instance.InstanceName.ToUpper()) {$instance.InstanceName='MSSQLSERVER'}
            
			Collect-SqlServerMinidumps -InstanceToCollect $instance.InstanceName -IsClustered $instance.IsClustered
        }
    }
} # if ($true -eq (Check-SqlServerIsInstalled))
else
{
    "[DC-CollectSqlSqlMinidumps] : [INFO] No SQL Server installation(s) were found on server: [{0}]" -f $env:ComputerName | WriteTo-StdOut
}
#endregion: MAIN ::::: 