﻿
if($debug -eq $true){[void]$shell.popup("Run DC_FCInfo.ps1")}
if ($OSArchitecture -eq 'ARM')
{
	'Skipping running {fcinfo.exe} since it is not supported in ' + $OSArchitecture + ' architecture.' | WriteTo-StdOut
	return
}
Import-LocalizedData -BindingVariable FCInfoStrings
	
Write-DiagProgress -Activity $FCInfoStrings.ID_FCInfo -Status $FCInfoStrings.ID_FCInfoRunning

#Rename binaries to the current processor architecture
$ProcArc = $Env:PROCESSOR_ARCHITECTURE

#_# Rename-Item -Path "fcinfo_$ProcArc.exe" -NewName "fcinfo.exe"
#_# Rename-Item -Path "hbaapi_$ProcArc.dll" -NewName "hbaapi.dll"
#_# Rename-Item -Path "hbatapi_$ProcArc.dll" -NewName "hbatapi.dll"

$fileDescription = $FCInfoStrings.ID_FCInfoOutput
$sectionDescription = $FCInfoStrings.ID_FCInfoOutputDesc
$OutputFile = $ComputerName + "_FCInfo.txt"
$CommandToExecute = "cmd.exe /c fcinfo.exe /diag > $OutputFile"

RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -BackgroundExecution
