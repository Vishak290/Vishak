﻿#************************************************
# GetDPMInfo.ps1
# Version 2.0.0
# Date: 09-27-2011
# Author: Patrick Lewis - patlewis@microsoft.com
# Description: This script gathers info on the DPM server
#************************************************

####################################################################################
# Check to be see if DPM is installed
####################################################################################
function IsDPMInstalled
{
	$IsDPMInstalled = $false
	if (Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup")
	{
		$IsDPMInstalled =(get-itemproperty "HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup").InstallPath 
		if(!([string]::IsNullOrEmpty($IsDPMInstalled)))
		{
			$IsDPMInstalled = $true
		}
	}
	return $IsDPMInstalled
}

####################################################################################
# Check to be sure the DPM namespace is loaded, if not then load it
####################################################################################
function LoadDPMNamespace ()
{	
	$DPMFolder = GetDPMInstallFolder	
	$DPMVersion = DPMVersion ($DPMFolder)
	Switch ($DPMVersion)
	{	
		2	{
				if (!(get-PSSnapin | ? { $_.name -eq 'Microsoft.DataProtectionManager.PowerShell'}))
				{
					Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
				}
			}
		3	{
				if (!(get-PSSnapin | ? { $_.name -eq 'Microsoft.DataProtectionManager.PowerShell'}))
				{
					Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
				}
			}
		4	{
				Import-Module -name dataprotectionmanager
			}
	}
} 

####################################################################################
# Check the command line arguments passed in
####################################################################################
function GetDPMServerName()
{
	if(!$args[0])
	{
		if(!$DPMServerName)
		{
			$DPMServerName = $Env:COMPUTERNAME
		}
	}
  
	$DPMServerName = $DPMServerName.Trim(" ")
	return $DPMServerName
}
####################################################################################
# PrintInfo
####################################################################################
function PrintInfo([string]$ServerName)
{
	"**************************************************" | out-file $OutputBase 
	"*          DPM Server Report Version 1.0         *" | out-file $OutputBase -Append
	"**************************************************" | out-file $OutputBase -Append

	$Server = get-wmiobject win32_operatingsystem
	$ds = Connect-DPMServer -DPMServerName $ServerName
   
	if (!$ds) 
	{
		"Unable to connect to DPM Server or service not running on: " + $ServerName | Out-File $OutputBase -Append
		$error[-1]                                                                  | Out-File $OutputBase -Append
		whoami                                                                      | Out-File $OutputBase -Append
		return
	}

	$dpmVersion = $ds.GetProductInformation().ProductName
	$Serverobj = New-Object PSObject
	$Serverobj | Add-Member NoteProperty -name "DPM Server" -value $ServerName
	$Serverobj | Add-Member NoteProperty -name "OS Version" -value $Server.Caption
	$Serverobj | Add-Member NoteProperty -name "Architecture" -value $Server.OSArchitecture
	$Serverobj | Add-Member NoteProperty -name "SP Level" -value $Server.ServicePackMajorVersion
	## TODO: Add entry for Total memory
	## TODO: Add pagefile size 1.5* Total memory
	$Serverobj | Add-Member NoteProperty -name "Available Memory" -value $Server.FreePhysicalMemory
	$Serverobj | Add-Member NoteProperty -name "DPM Version" -value $dpmVersion
	$Serverobj | Add-Member NoteProperty -name "DPM Build" -value $ds.GetProductInformation().Version.ToString()

	$Serverobj | Out-File $OutputBase -append

	#Now that we have a valid connect let's get the disk information for the dpmServer
	[System.Array]$dpmDisk = Get-DPMDisk $ServerName 

	#Gather tape library info
	$dpmLibrary = Get-DPMLibrary -DPMServerName $ServerName

	#Build list of datasources and protection groups
	$dpmPG = Get-ProtectionGroup -DPMServerName $ServerName
	
	"**************************************************" | Out-File $OutputBase -append
	"*          STORAGE POOL DISK INFORMATION         *" | Out-File $OutputBase -append
	"**************************************************" | Out-File $OutputBase -append
	$dpmDisk | Format-List | Out-File $OutputBase -append

	"**************************************************" | Out-File $OutputBase -append
	"*          TAPE LIBRARY INFORMATION              *" | Out-File $OutputBase -append
	"**************************************************" | Out-File $OutputBase -append
	# We have to check to be sure a tape library is present...
	if ($dpmLibrary)
	{   
		$dpmLibrary | Format-List |  Out-File $OutputBase -append
		"**************************************************" | Out-File $OutputBase -append
		"*          TAPE DRIVE INFORMATION                *" | Out-File $OutputBase -append
		"**************************************************" | Out-File $OutputBase -append
		$TDobj = New-Object PSObject
			foreach ($TapeLib in $dpmLibrary)
			{
				$TDobj | Add-Member NoteProperty -Force -name "Name" -value $TapeLib.UserFriendlyName
				$TDobj | Add-Member NoteProperty -Force -name "Product ID" -value $TapeLib.ProductId
				$TDobj | Add-Member NoteProperty -Force -name "Serial #" -value $TapeLib.SerialNumber
				$TDobj | Add-Member NoteProperty -Force -name "Tape Drive Enabled?" -value $TapeLib.IsEnabled
				$TDobj | Add-Member NoteProperty -Force -name "Tape Drive offline?" -value $TapeLib.IsOffline
				$TDobj | Out-File $OutputBase -append
			}
	} else {
		"WARNING: NO TAPE LIBRARIES FOUND" | Out-File $OutputBase -append
	}

	"**************************************************" | Out-File $OutputBase -append
	"*          PROTECTION GROUPS                     *" | Out-File $OutputBase -append
	"**************************************************" | Out-File $OutputBase -append
    ""                                                   | Out-File $OutputBase -append

	if ($dpmPG)
	{
#-------------------------------------------------- NEW CHANGE START -------------------
		add-pssnapin sqlservercmdletsnapin100 -ErrorAction SilentlyContinue
		Push-Location; Import-Module SQLPS -ErrorAction SilentlyContinue ; Pop-Location

        function recovery ($Datasource)
        {
            $RPList = @(Get-RecoveryPoint $Datasource)
            if ($RPList.count -gt 0)
            {
                "             Backup Time              Location   Generation" | Out-File $OutputBase -append
                "             ----------------------   --------   ----------" | Out-File $OutputBase -append
                foreach ($RP in $RPList)
                {
                    ("             {0,22}   {1,8}   {2}" -f $rp.BackupTime, $RP.Location, $RP.RecoverySourceLocations.generation) | Out-File $OutputBase -append
                }     
            }
            else
            {
                "             No recovery point found for this datasource" | Out-File $OutputBase -append
            }
        }

        # Get DPM server FQDN and DPM Database
        $DPMServerConnection = (Connect-DPMServer (&hostname))
        $DPMServer = $DPMServerConnection.name

        # Find out where DPMDB is located for he local DPM Server
        $DPMDB = $dpmserverconnection.dpmdatabaselogicalpath.substring($dpmserverconnection.DPMDatabaseLogicalPath.LastIndexOf('\') + 1,$dpmserverconnection.DPMDatabaseLogicalPath.Length - $dpmserverconnection.DPMDatabaseLogicalPath.LastIndexOf('\') -1 )
        $DPM   = $dpmserverconnection.dpmdatabaselogicalpath.substring(0,$dpmserverconnection.DPMDatabaseLogicalPath.LastIndexOf('\'))

        $DPMMajorVersion = (dir ((get-itemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\setup\").installpath + "bin\msdpm.exe")).VersionInfo.fileversion.split('.')[0]
        
        $PGList = @(Get-ProtectionGroup (&hostname) | Sort-Object name)
        foreach ($pg in $PGList)
        {
            if ($DPMMajorVersion -eq '3') # DPM 2010
            {
               "Protection Group............: " + $pg.friendlyname | out-file $OutputBase -append
            }
            else
            {
              "Protection Group............: " + $pg.name             | out-file $OutputBase -append
              "Protection Method...........: " + $pg.ProtectionMethod | out-file $OutputBase -append
              if ($pg.IsDiskShortTerm)
              {
                    "Short-Term Disk Backup time.: " + (Get-DPMPolicySchedule -ProtectionGroup $PG -ShortTerm).ScheduleDescription | out-file $OutputBase -append
                    "Short-Term Disk Retention...: " + (Get-DPMPolicyObjective -ProtectionGroup $pg -ShortTerm).retentionrange.range + " " + (Get-DPMPolicyObjective -ProtectionGroup $pg -ShortTerm).retentionrange.unit | out-file $OutputBase -append
              }
              if ($pg.IsTapeShortTerm)
              {
                    "Short-Term Tape Backup time.: " + (Get-DPMPolicySchedule -ProtectionGroup $PG -ShortTerm).ScheduleDescription | out-file $OutputBase -append
                    "Short-Term Tape Retention...: " + $pg.ArchiveIntent.RetentionPolicy.OnsiteFather.ToString() | out-file $OutputBase -append
            }
              if ($pg.IsTapeLongTerm)
              {
                    "Long-Term Backup time Goal 1: " + @((Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape) | sort-object jobtype -Descending)[0].ScheduleDescription  | out-file $OutputBase -append
                    "Long_term Retention Goal 1..: " + $pg.ArchiveIntent.RetentionPolicy.OffsiteFather.ToString() | out-file $OutputBase -append
                    if ($pg.ArchiveIntent.RetentionPolicy.OffsiteGrandfather.Enabled)
                    {
                        "Long-Term Backup time Goal 2: " + @((Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape) | sort-object jobtype -Descending)[1].ScheduleDescription | out-file $OutputBase -append
                        "Long_term Retention Goal 2..: " + $pg.ArchiveIntent.RetentionPolicy.OffsiteGrandfather.ToString() | out-file $OutputBase -append
                        if ($pg.ArchiveIntent.RetentionPolicy.OffsiteGreatGrandfather.Enabled)
                        {
                            "Long-Term Backup time Goal 3: " + @((Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape) | sort-object jobtype -Descending)[2].ScheduleDescription | out-file $OutputBase -append
                            "Long_term Retention Goal 3..: " + $pg.ArchiveIntent.RetentionPolicy.OffsiteGreatGrandfather.ToString() | out-file $OutputBase -append
                        }
                    }
              }
              if ($pg.IsCloudLongTerm)
            {
                    "Online Backup time..........: " + (Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm online).scheduledescription | out-file $OutputBase -append
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeDaily.range)
                    {
                        "Daily Retention Range.......: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeDaily.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeDaily.unit | out-file $OutputBase -append
                    }
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeWeekly.range)
                    {
                        "Weekly Retention Range......: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeWeekly.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeWeekly.unit | out-file $OutputBase -append
                    }
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeMonthly.range)
                    {
                        "Monthly Retention Range.....: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeMonthly.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeMonthly.unit | out-file $OutputBase -append
                    }
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeYearly.range)
                    {
                        "Yearly Retention Range......: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeYearly.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeYearly.unit | out-file $OutputBase -append
                    }
              }

              "Performance Optimization....: " + $pg.PerformanceSettings | out-file $OutputBase -append
            }
            $DSList = @(Get-Datasource $pg | Sort-Object ProductionServerName, name)
            $ComputerName = $DSList[0].ProductionServerName
            "   Computer: " + $ComputerName | out-file $OutputBase -append
            foreach ($DS in $DSList)
            {
                if ($ds.ProductionServerName -ne $ComputerName)
                {
                    $ComputerName = $DS.ProductionServerName
                    "   Computer: " + $ComputerName | out-file $OutputBase -append
                }
                ("       type: {0,-20} - Datasource Name: {1}" -f $ds.ObjectType, $ds.DisplayPath ) 
                ("       type: {0,-20} - Datasource Name: {1}" -f $ds.ObjectType, $ds.DisplayPath ) | out-file $OutputBase -append
        	    if ($DPMMajorVersion -eq '3') # DPM 2010
                {
                   $ObjectType = $ds.type.name
                }
                else
                {
                   $ObjectType = $ds.ObjectType
                }

                switch ($ObjectType)
                {
                    'System Protection' {   $query = "select ComponentName 
                                                      from tbl_IM_ProtectedObject 
                                                      where ProtectedInPlan = 1 and 
	                                                  (ComponentName like 'Bare Metal Recovery' or ComponentName like 'System State') and 
	                                                  DataSourceId like '"+ $ds.DatasourceId + "'"
                                            $DSTypeList = @(Invoke-Sqlcmd -ServerInstance $DPM -Database $DPMDB -Query $query)
                                            foreach ($DSType in $DSTypeList)
                                            {                                        
                                                "            " + $DSType.ComponentName | out-file $OutputBase -append
                                            }
                                        }
                    'SharePoint Farm'   {   $query = "select ComponentName 
                                                      from tbl_IM_ProtectedObject 
                                                      where ProtectedInPlan = 1 and
	                                                  ReferentialDataSourceId like '"+ $ds.DatasourceId + "' order by convert(varchar(max),LogicalPath)"
                                            $DSTypeList = @(Invoke-Sqlcmd -ServerInstance $DPM -Database $DPMDB -Query $query)
                                            foreach ($DSType in $DSTypeList)
                                            {                                        
                                                 "         " + $DSType.ComponentName | out-file $OutputBase -append
                                           }
                                        }
                    'Volume'            {   $query = "select LogicalPath
                                                      from tbl_IM_ProtectedObject 
                                                      where ProtectedInPlan = 1 and
	                                                  DataSourceId like '"+ $ds.DatasourceId + "' order by convert(varchar(max),LogicalPath)"
                                            $DSTypeList = @(Invoke-Sqlcmd -ServerInstance $DPM -Database $DPMDB -Query $query)
                                            Foreach ($DSType in $DSTypeList)
                                            {
                                                [xml]$xml = $DSType.LogicalPath
                                                $type = ($xml.ArrayOfInquiryPathEntryType.InquiryPathEntryType)[-1]
                                                if ($type.type -eq 'NonRootTargetShare')
                                                {
                                                    "             Share  - " +  $Type.value | out-file $OutputBase -append
                                                }
                                                else
                                                {
                                                    "             " + $type.type + " - " + $Type.value | out-file $OutputBase -append
                                                }
                                            }
                                        }
                }
            }
            "" | out-file $OutputBase -append
        }
#-------------------------------------------------- NEW CHANGE END   -------------------
<#
		$dpmPG | Format-List | Out-File $OutputBase -append
		"--------------------------------------------------" | Out-File $OutputBase -append
		"Shorterm Retention Range: " | Out-File $OutputBase -append
		$dpmPG.OnsiteRecoveryrange | fl | Out-File $OutputBase -append
		"--------------------------------------------------" | Out-File $OutputBase -append
		"Longterm Retention Range: " | Out-File $OutputBase -append
		$dpmPG.OffsiteRecoveryRange | fl | Out-File $OutputBase -append

		foreach ($pgName in $dpmPG)
		{
			"**************************************************" | Out-File $OutputBase -append
			"Protection Group: " + $pgName.FriendlyName | Out-File $OutputBase -append
			"**************************************************" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			"*          DATA SOURCES SUMMARY                  *" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			$dpmDS = Get-Datasource -ProtectionGroup $pgName
			$dpmDS | format-list -property ProductionServerName, Name | Out-File $OutputBase -append
 
			#Now go through each datasource and print additional info
			"--------------------------------------------------" | Out-File $OutputBase -append
			"*          DATA SOURCE DETAILS                   *" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			#Setup an event since Get-DataSource is async
			$global:DSCount = 0
			$LoopCounter = 0
			foreach ($dsName in $dpmDS)
			{
				if ($dsName.TotalRecoveryPoints -eq 0) {
					Register-ObjectEvent -InputObject $dsName -EventName DatasourceChangedEvent -SourceIdentifier "EVENT$LoopCounter" -Action {$global:DSCount++} 
					$LoopCounter++
				} else {
					$global:DSCount++
				}
			}

			#trigger the event to signal
			$dpmDS.TotalRecoveryPoints > $null

			#Check to see if signaled yet
			if ($dpmDS.TotalRecoveryPoints -eq 0)
			{
				$begin = get-date
				$m = Measure-Command {
					while (((Get-Date).subtract($begin).seconds -lt 120) -and ($global:DSCount -ne 0))
					{
						sleep -Milliseconds 100
					}
				}
			}

			#Event has been signaled or we reached the 120 second timeout. Now update the datasources
			$dpmDS = Get-Datasource -ProtectionGroup $pgName
			$DSObj = New-Object PSObject

			foreach ($dsName in $dpmDS)
			{
				$DSobj | Add-Member NoteProperty -Force -name "Computer" -value $dsName.ProductionServerName
				$DSobj | Add-Member NoteProperty -Force -name "Datasource Name" -value $dsName.Name
				$DSobj | Add-Member NoteProperty -Force -name "Disk allocation" -value  $dsName.DiskAllocation
				$DSobj | Add-Member NoteProperty -Force -name "Total recovery points" -value $dsName.TotalRecoveryPoints

				if ($dsName.TotalRecoveryPoints -ne 0) 
				{
					$DSobj | Add-Member NoteProperty -Force -name "Latest recovery point" -value $dsName.LatestRecoveryPoint
					$DSobj | Add-Member NoteProperty -Force -name "Oldest recovery point" -value $dsName.OldestRecoveryPoint
				} else {
					if ($dsName.TotalRecoveryPoints -eq 0)
					{
						$DSobj | Add-Member NoteProperty -Force -name "Latest recovery point" -value "NO VALID RECOVERY POINTS"
						$DSobj | Add-Member NoteProperty -Force -name "Oldest recovery point" -value "NO VALID RECOVERY POINTS"
					} else {
						$DSobj | Add-Member NoteProperty -Force -name "Latest recovery point" -value $dsName.LatestRecoveryPoint
						$DSobj | Add-Member NoteProperty -Force -name "Oldest recovery point" -value $dsName.OldestRecoveryPoint
					}
				}
			}
			# Unregister-Event *
			$DSObj | Out-File $OutputBase -append

			#Now add longterm backup info

			"--------------------------------------------------" | Out-File $OutputBase -append
			"*              LONG TERM - TAPE                  *" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			switch ($dpmversion)
			{
				"Microsoft System Center Data Protection Manager 2010" {
					$policySchedule = @(Get-PolicySchedule -ProtectionGroup $pgName -longterm tape)
					}
				default {
					"NOT TESTED ON THIS DPM VERSION" | Out-File $OutputBase -append
					 }
			}

			$tb = Get-TapeBackupOption $pgName;$tb.labelinfo
			$label = @($tb.label);
			$count = $policySchedule.count -1
			while ($count -ne -1)
			{
				if ($label[$count].length -eq 0 -or $label[$count].length -eq $null)
				{ 
					"Default Label Name" | Out-File $OutputBase -append
				}
				else
				{
					"Tape Label: " + $label[$count] | Out-File $OutputBase -append
				}
				$policyschedule[$count] | fl * | Out-File $OutputBase -append
				$count--
			}
		}
		"--------------------------------------------------" | Out-File $OutputBase -append
		"* TAPES LOADED INTO SLOTS THAT ARE OFFLINE READY *" | Out-File $OutputBase -append
		"--------------------------------------------------" | Out-File $OutputBase -append
		$count = 0
		$dpmLibrary = @($dpmlibrary | ? { $_.Isoffline -eq $false })
		if ($dpmlibrary)
		{
			foreach ($library in $dpmlibrary)
			{
				$tapelist = get-tape $library
				foreach ($tape in $tapelist)
				{
					if ($tape.IsOffsiteReady -eq $true)
					{
						("{0,-30} | {1,-9} | {2,-25} | {3,-50}" -f $tape.libraryname, $tape.location, $tape.barcode, $tape.Label) | Out-File $OutputBase -append
						$count++
					}
				}
			}
			if ($count -eq 0)
			{
				"No Tapes are marked as offsite ready"  | Out-File $OutputBase -append
			}
		}
		else
		{
			"No online library was found on this system"  | Out-File $OutputBase -append
		}
	}
#>  
}
else {
		"WARNING: NO PROTECTION GROUPS FOUND" | Out-File $OutputBase -append
	}

	return
}

####################################################################################
# Main
####################################################################################
Import-LocalizedData -BindingVariable LocalizedGetDPMInfo -FileName DC_GetDPMInfo -UICulture en-us

Write-DiagProgress -Activity $LocalizedGetDPMInfo.ID_DPM_ACTIVITY -Status $LocalizedGetDPMInfo.ID_DPM_STATUS_GetDPMInfo

# Check first to be sure DPM is installed otherwise exit
if (IsDPMInstalled)
{
	$LocalizedGetDPMInfo.ID_DPM_INSTALLED | ConvertTo-Xml | Update-DiagReport -Id $LocalizedGetDPMInfo.ID_DPM_INFO -Name $LocalizedGetDPMInfo.ID_DPM_INFORMATION
} else {
	$LocalizedGetDPMInfo.ID_DPM_NOT_INSTALLED | ConvertTo-Xml | Update-DiagReport -Id $LocalizedGetDPMInfo.ID_DPM_INFO -Name $LocalizedGetDPMInfo.ID_DPM_INFORMATION -verbosity "Warning"
	exit 1
}

$DPMVersion = DPMVersion (GetDPMInstallFolder)
if($DPMVersion -ne $null)
{
	$DPMServerName = GetDPMServerName
	$OutputBase= $DPMServerName + "_DPM_Info.txt"
	LoadDPMNamespace

	# Prints the info
	PrintInfo $DPMServerName

	Disconnect-DPMServer -DPMServer $DPMServername
	CollectFiles -filesToCollect $OutputBase -fileDescription $LocalizedGetDPMInfo.ID_DPM_SETTINGS -sectionDescription $LocalizedGetDPMInfo.ID_DPM_INFORMATION

	exit 0
}
else
{
	"Script DC_GetDPMInfo.ps1 running on a Protected Server, no data will be collected" | WriteTo-StdOut -ShortFormat
}

# SIG # Begin signature block
# MIIa5QYJKoZIhvcNAQcCoIIa1jCCGtICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUEi/LFwt2iIYF6uuAPEnvhWKa
# Az+gghWDMIIEwzCCA6ugAwIBAgITMwAAAJvgdDfLPU2NLgAAAAAAmzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwMzMwMTkyMTI5
# WhcNMTcwNjMwMTkyMTI5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjcyOEQtQzQ1Ri1GOUVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjaPiz4GL18u/
# A6Jg9jtt4tQYsDcF1Y02nA5zzk1/ohCyfEN7LBhXvKynpoZ9eaG13jJm+Y78IM2r
# c3fPd51vYJxrePPFram9W0wrVapSgEFDQWaZpfAwaIa6DyFyH8N1P5J2wQDXmSyo
# WT/BYpFtCfbO0yK6LQCfZstT0cpWOlhMIbKFo5hljMeJSkVYe6tTQJ+MarIFxf4e
# 4v8Koaii28shjXyVMN4xF4oN6V/MQnDKpBUUboQPwsL9bAJMk7FMts627OK1zZoa
# EPVI5VcQd+qB3V+EQjJwRMnKvLD790g52GB1Sa2zv2h0LpQOHL7BcHJ0EA7M22tQ
# HzHqNPpsPQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJaVsZ4TU7pYIUY04nzHOUps
# IPB3MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBACEds1PpO0aBofoqE+NaICS6dqU7tnfIkXIE1ur+0psiL5MI
# orBu7wKluVZe/WX2jRJ96ifeP6C4LjMy15ZaP8N0OckPqba62v4QaM+I/Y8g3rKx
# 1l0okye3wgekRyVlu1LVcU0paegLUMeMlZagXqw3OQLVXvNUKHlx2xfDQ/zNaiv5
# DzlARHwsaMjSgeiZIqsgVubk7ySGm2ZWTjvi7rhk9+WfynUK7nyWn1nhrKC31mm9
# QibS9aWHUgHsKX77BbTm2Jd8E4BxNV+TJufkX3SVcXwDjbUfdfWitmE97sRsiV5k
# BH8pS2zUSOpKSkzngm61Or9XJhHIeIDVgM0Ou2QwggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTMMIIE
# yAIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHlMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBQ5
# 9AblAmjnckORWDCV1lNwJMCNhzCBhAYKKwYBBAGCNwIBDDF2MHSgWoBYAFMAeQBz
# AHQAZQBtAEMAZQBuAHQAZQByAEQAUABNAF8ATQBBAEIAXwBnAGwAbwBiAGEAbABf
# AEQAQwBfAEcAZQB0AEQAUABNAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRwOi8vbWlj
# cm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQCtboRButOqjlRD+31COCD+eEmR
# BXcWhyr6Eahppmg9TVYdqyrY4l28+81QSrAYve/vXwcPY+Yu1yJbafAAoglQ9of4
# Ppbm//gQ/aHaAqS79+Rx1bdX7QXffb+UeVZvHaZsBmCD0xl5PRP1l0sdJkzBkqFP
# tCzihVEwG7giqUHHGHzAiebS6fqelCwcxpJjzhaTE8DQ0evF1TbRZxJmqrVhK2sX
# +3Amfl7kSpXhNqbNHeKgjlN7XxkCAR6CWuMw28jlPzEYwrv0/IQVcBAtf3V6Smkv
# S0N7I39CSidklitUC72nj+A5iD1ItsOAHwRh7GeO+7f9mq5yRvfM5gy0Vd19oYIC
# KDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQQITMwAAAJvgdDfLPU2NLgAAAAAAmzAJBgUrDgMCGgUAoF0wGAYJKoZI
# hvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTYwODMwMjEzMTUw
# WjAjBgkqhkiG9w0BCQQxFgQURQLCL4/0UjGvFa6+ZYNENHRn0z8wDQYJKoZIhvcN
# AQEFBQAEggEAEns62v3aKMjPUt1tyPrvkNU4p8RLvitDQP0iSz6FlnqYmEJmUMLe
# q4r1kEcVrBRdxJCgbRKr7CHYGzZ0r5nAWuhyhHOnocftdmJd3xec5N/3RiQCGdPa
# 9yA/Fsu39CcAePxU1eWY0WSsJC4MNZbGDBHprmq8SOueWQgOPUJp2i8sQmLt5K7n
# tPRlzJWoi463VCp6SClFX3/L7mhSIK5aKMI15HqCHif0Pj1xYoPNyjPiqE4WEdPm
# e8PRYNiPXAQQQcXMcq+tkUHmIVBvFe/rNZdKVUTPjDDUO6GcMY9JVko9ZId0XpEo
# LyzXbCGTqkVP580AZWKxao4ANvUcSttxLQ==
# SIG # End signature block
