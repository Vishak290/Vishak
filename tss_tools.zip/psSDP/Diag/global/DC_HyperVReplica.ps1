﻿#************************************************
# DC_HyperVReplica.ps1
# Version 1.0 - 7/24/14
# Author: jasonf
#*******************************************************


Trap [Exception]
	{
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable


Function TestRemoteMachineConnectivity([string] $RemoteMachine)
{
	$Error.Clear()
	
	trap [Exception] 
	{
		WriteTo-ErrorDebugReport -ErrorRecord $Error[0] -ScriptErrorText ("[TestRemoteMachineConnectivity] Remote Machine: $RemoteMachine")
		continue
	}
	
	$Win32OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $RemoteMachine -ErrorAction SilentlyContinue
	
	if ($Error.Count -gt 0)
	{
		#_# get-diaginput -id "ErrorConnectingMachine" -Parameter @{"Machine"=$RemoteMachine; "Error"= $Error[0].Exception.Message}
		"...skipping #_# get-diaginput -id ErrorConnectingMachine: RemoteMachine $RemoteMachine" | WriteTo-StdOut
		$Error.Clear()
		return $null
	} 
	else 
	{
		Return $Win32OS
	}
}



$sectionDescription = "Hyper-V Replica Settings"

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile = $Computername + "_HyperVReplica_info.TXT"

$vmmsCheck = Test-path "HKLM:\SYSTEM\CurrentControlSet\Services\vmms"
if ($vmmsCheck)
{
	if ((Get-Service "vmms").Status -eq 'Running')
	{
		if ($bn -gt 9000) 
		{
			$VMsConfiguredForReplication = get-vmreplication
			if ($VMsConfiguredForReplication.count -gt 0)
			{
				$Choices = @()
		
				foreach ($VM in $VMsConfiguredForReplication)
				{
					$VMName = $VM.Name
					$ExtensionPoint = ""
					$Choices += @{"Name"=$VMName;"Value"=$VMName;"Description"=$VMName;"ExtensionPoint"=$ExtensionPoint}
			
				}

				$TroubleshootingVMNames = @()
		
				"Choices: " | WriteTo-StdOut
				$Choices | WriteTo-StdOut
		
				if ($Choices.Count -gt 0)
				{
					do
					{
						#_# $TroubleshootingvMNames += Get-DiagInput -Id "SelectVMs" -Parameter (@{"VMs"="Virtual Machines"}) -Choice $Choices
						"...skipping #_# get-diaginput -id SelectVMs: " | WriteTo-StdOut
				
					} while ($TroubleshootingVMNames.Count -eq 0)

					"VMs Selected: " | WriteTo-StdOut
					$TroubleshootingVMNames | WriteTo-StdOut

					#get hostnames to collect data from
					$arrHostNames = @()
					foreach ($vm in $TroubleshootingVMNames)
					{
						$vmReplication = get-vmreplication $vm
						$clusterNodes = @()
						$clusterNodes = (gwmi -Query "select * from mscluster_nodetoactivegroup" -namespace "root\mscluster" -computername $vmReplication.PrimaryServer -ErrorAction SilentlyContinue).PSComputername
						if ($clusterNodes.Count -gt 0)
						{
							$arrHostNames += $clusterNodes
						}
						else
						{
							$arrHostNames += $vmReplication.PrimaryServer
						}
						$clusterNodes = @()
						$clusterNodes = (gwmi -Query "select * from mscluster_nodetoactivegroup" -namespace "root\mscluster" -computername $vmReplication.ReplicaServer -ErrorAction SilentlyContinue).PSComputername
						if ($clusterNodes.Count -gt 0)
						{
							$arrHostNames += $clusterNodes
						}
						else
						{
							$arrHostNames += $vmReplication.ReplicaServer
						}
					}
					$arrHostNames = $arrHostNames | sort-object -uniq

					if ($arrHostNames.Count -gt 0)
					{
						. ./TS_RemoteSetup.ps1

						foreach ($RemoteHostName in $arrHostNames)
						{
							$TestClientConnectivity = TestRemoteMachineConnectivity -RemoteMachine $RemoteHostName
							if ($testClientConnectivity -ne $null)
							{
								$RemoteExpression = $null
								foreach ($vm in $TroubleshootingVMNames)
								{
									$RemoteExpression += "Run-DiagExpression .\DC_HVRHost.ps1 -VMNames $vm `n "
								}
								ExecuteRemoteExpression -ComputerNames $RemoteHostName -Expression $RemoteExpression
							}
						}
					}

				}
				else 
				{
					#get-diaginput -id "ErrorContactingNode" -Parameter @{"Machine"=$NodeName; "Error"=$ScriptStrings.ID_EPSSelectNodesUnableObtainNames}
					"...skipping #_# get-diaginput -id ErrorContactingNode Machine=$NodeName" | WriteTo-StdOut
					"[info]: no vms selected" | WriteTo-StdOut
				}
			} 
			else
			{
				"This server does not have any VMs configured to replicate."	| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"This server is not running WS2012 or WS2012 R2."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Hyper-V Virtual Machine Management`" service is not running."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Hyper-V Virtual Machine Management`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}

