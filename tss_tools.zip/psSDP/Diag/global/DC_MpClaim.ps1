﻿# File DC_Mpclaim.ps1
# Copyright 2020, Microsoft Corporation. All rights reserved.


if($debug -eq $true){[void]$shell.popup("Run DC_Mpclaim.ps1")}

Import-LocalizedData -BindingVariable VerifierStrings

if (test-path $env:Windir\System32\mpclaim.exe){
	Write-DiagProgress -Activity $VerifierStrings.ID_mpclaimDC -Status $VerifierStrings.ID_mpclaimDCObtaining

	$OutputFile = $ComputerName + "_mpclaim.txt"
	$CommandLineToExecute = "cmd.exe /c mpclaim.exe -v $OutputFile -n"

	RunCmD -commandToRun $CommandLineToExecute -sectionDescription $VerifierStrings.ID_mpclaimDCOutputDesc -filesToCollect $OutputFile -fileDescription $VerifierStrings.ID_mpclaimDCOutput
}