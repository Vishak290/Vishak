﻿# File DC_RegistryStorage.ps1
# Copyright 2020, Microsoft Corporation. All rights reserved.

Import-LocalizedData -BindingVariable UtilsRegistrySetupPerf

$OutputFile= $Computername + "_reg_MountedDevices.TXT"
RegQuery -RegistryKeys "HKLM\System\MountedDevices" -OutputFile $OutputFile -fileDescription "MountedDevices"

$OutputFile= $Computername + "_reg_MountedDevices.HIV"
RegSave -RegistryKey "HKLM\System\MountedDevices" -OutputFile $OutputFile -fileDescription "MountedDevices"

$iSCSIKeys =  "HKLM\SYSTEM\CurrentControlSet\Services\iScsiPrt",
			"HKLM\SOFTWARE\Microsoft\iSCSI Target",
			"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\iSCSI"

$OutputFile= $Computername + "_reg_iSCSI.TXT"
RegQuery -RegistryKeys $iSCSIKeys -OutputFile $OutputFile -fileDescription "iSCSI" -Recursive $true

$StorageKeys =  "HKLM\System\CurrentControlSet\Control\MPDEV",
			"HKLM\System\CurrentControlSet\Control\iSCSIPRT",
			"HKLM\System\CurrentControlSet\Services\MSiSCSI",
			"HKLM\System\CurrentControlSet\Services\MSDSM",
			"HKLM\System\CurrentControlSet\Services\MPIO",
			"HKLM\System\CurrentControlSet\Control\Class\{4d36e97b-e325-11ce-bfc1-08002be10318}",
			"HKLM\System\CurrentControlSet\Services\Tcpip"			

$OutputFile= $Computername + "_reg_Storage.TXT"
RegQuery -RegistryKeys $StorageKeys -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfStorage -Recursive $true

$OutputFile= $Computername + "_reg_Enum.TXT"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Enum" -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfEnum -Recursive $true
