﻿#************************************************
# DC_Zip2.ps1
# Version 1.0.1
# Date: 05-09-2011
# Author: Jeremy LaBorde - jlaborde@microsoft.com
# Original Author: Louis Shanks - louiss@microsoft.com
# Description: This script is a utility to 
#              Zip files\folders
#
# two behavioral changes to out-zip and added addto-zip
#
#************************************************


 
# Import-LocalizedData -BindingVariable DSIZIP 



#######################################################
###												   	###	
### out-zip function()								###
###													###
###  Accepts an array of folders\files to compress	###
###  Accepts a name to be used as the zipfile name	###
###													###
###  Returns the file path\name of the new zip		###
###													###
### updated: 5-5-2011, jlaborde			   	###	
###												   	###	
#######################################################

function out-zip ($FilePath, $zipFileName, $activity, $status){
#		Write-DiagProgress -Activity $activity -Status $status
		
		#Build up the zip file name.
		#  5-5-2011: fix an issue here to check for '\' and only append if needed
		if( $PWD.Path.EndsWith( "\" ) -eq $false )
		{	$ZipFileName = ($PWD.Path) + "\" + $zipFileName
		} else
		{	$ZipFileName = ($PWD.Path) + $zipFileName
		}
				
		if (-not $zipFileName.EndsWith('.zip')) {$zipFileName += '.zip'} 				

		# 5-5-2011: removed "($env:COMPUTERNAME + "_") + " from being added to the start of the file name
		#  as it causes issues if you use a partial path, like folder\file.zip
		if (-not (Test-Path($ZipFileName))) {Set-Content $ZipFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))}

		#create Zip object
		$ZipFileObj = (new-object -com Shell.Application).NameSpace($ZipFileName)
		
		$sleepCounter = 0
		$zipItemCounter = 0
		$InitialZipItemCount = $ZipFileObj.Items().Count			
		
		#Loop through the Folder\file list
		foreach ($file in $FilePath){
		
			#place the file into the zip object
			$ZipFileObj.CopyHere($file.FullName)
			$zipItemCounter += 1
						
			do{
				sleep -Milliseconds 200
				$sleepCounter += 1
			} while (($ZipFileObj.Items().Count -lt $zipItemCounter) -and ($sleepCounter -lt 600))
		}

		#send back the zipfile pointer
		return $zipFileName
}

#######################################################
###												   	###	
### AddTo-zip function()								###
###													###
###  Assumes a pre-existing zip and adds files to it	###
###													###
### updated: 5-5-2011, jlaborde			   	###	
###												   	###	
#######################################################

function AddTo-Zip( $FileToAdd, $ZipFileName, $activity, $status )
{	#Write-DiagProgress -Activity $activity -Status $status

	(dir $ZipFileName).IsReadOnly	= $false 
	$ZipFileObj						= (new-object -com Shell.Application).NameSpace($ZipFileName)
	$file							= Get-Item $FileToAdd

	$sleepCounter					= 0
	$zipItemCounter					= $ZipFileObj.Items().Count
	$InitialZipItemCount			= $ZipFileObj.Items().Count
	
	$ZipFileObj.CopyHere( $FileToAdd )
	$zipItemCounter += 1
					
	do{	sleep -Milliseconds 200
		$sleepCounter += 1
	} while( ($ZipFileObj.Items().Count -lt $zipItemCounter) -and ($sleepCounter -lt 600) )

	return $ZipFileName
}
