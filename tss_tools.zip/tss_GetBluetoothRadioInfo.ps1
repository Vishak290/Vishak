# Copyright and License https://github.com/Microsoft/busiotools/blob/master/LICENSE
# Script: GetBluetoothRadioInfo.ps1
#region ::::: Script Input PARAMETERS :::::
[CmdletBinding()]param(
 [Parameter(Mandatory=$true, Position=0)] [String] $DataPath
)
$ScriptVer="1.00"	#Date: 2019-05-10


function Get-BluetoothRadioInfo
# SYNOPSIS: collect BluetoothRadio Info
{
	$devices = Get-PnpDevice -Class Bluetooth -EA SilentlyContinue |? InstanceId -notlike "BTH*"
	if ($devices -ne $null) {
		$radios = New-Object System.Collections.ArrayList
		foreach ($device in $devices)
		{   
			$radio = New-Object PSObject
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "InstanceId" -Value $device.InstanceId
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Bluetooth_RadioAddress'
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "MAC" -Value $(-join ($property.Data |  foreach { "{0:X2}" -f $_ } ))
			$radios.Add($radio) | Out-Null

			# Driver Info
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_DriverDesc'
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "DriverDescription" -Value $property.Data
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName 'DEVPKEY_Device_DriverVersion'
			Add-Member -InputObject $radio -MemberType NoteProperty -Name "DriverVersion" -Value $property.Data

			# Error Recovery
			$property = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName '{A92F26CA-EDA7-4B1D-9DB2-27B68AA5A2EB} 14'
			$supportedTypes = $property.Data
			if ($supportedTypes -eq 0)
			{
				Add-Member -InputObject $radio -MemberType NoteProperty -Name "ErrorRecovery" -Value "None"
			} elseif ($supportedTypes -band 1 -shl 0)
			{
				Add-Member -InputObject $radio -MemberType NoteProperty -Name "ErrorRecovery" -Value "FLDR"
			} elseif ($supportedTypes -band 1 -shl 1)
			{
				Add-Member -InputObject $radio -MemberType NoteProperty -Name "ErrorRecovery" -Value "PLDR"
			}
			
		}
		$radios | Format-Table
	}
} # end of function Get-BluetoothRadioInfo

#region ::::: MAIN ::::
$InfoFileName = $dataPath + '\' + $env:COMPUTERNAME + '_BluetoothRadioInfo.txt'
Get-BluetoothRadioInfo |Out-File $InfoFileName
#endregion ::::: MAIN :::::